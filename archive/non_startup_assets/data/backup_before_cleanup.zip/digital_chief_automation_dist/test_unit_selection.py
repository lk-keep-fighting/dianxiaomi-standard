#!/usr/bin/env python3
"""
测试复合组件的单位选择功能
验证尺寸、重量等字段的Measure和Unit都能正确填充
"""
import sys
import os

# 添加src目录到Python路径
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from form_config_listener import FormConfigListener, FormFieldParser
from dynamic_form_filler import DynamicFormFiller

def test_dimension_field_identification():
    """测试尺寸字段识别"""
    print("🧪 测试复合组件字段识别...")
    
    listener = FormConfigListener()
    config = listener.load_config()
    
    if not config:
        print("⚠️ 未找到表单配置文件")
        return False
    
    parser = FormFieldParser(config)
    all_fields = parser.get_all_fields()
    
    # 查找所有可能的复合组件字段
    composite_fields = []
    for field in all_fields:
        field_title = field['title']
        if any(keyword in field_title for keyword in ['Assembled Product', 'Shipping Weight', 'Product Weight', 'Dimension']):
            composite_fields.append(field)
    
    print(f"📋 发现 {len(composite_fields)} 个潜在的复合组件字段:")
    for field in composite_fields[:10]:  # 显示前10个
        print(f"  - {field['title']} (类型: {field['input_type']})")
    
    # 重点关注尺寸相关字段
    dimension_fields = [f for f in composite_fields if any(keyword in f['title'] for keyword in ['Depth', 'Width', 'Height', 'Weight'])]
    print(f"\n🔍 重点关注的尺寸/重量字段 ({len(dimension_fields)}个):")
    for field in dimension_fields:
        print(f"  - {field['title']} -> {field['input_type']} 类型")
    
    return dimension_fields

def test_unit_selection_logic():
    """测试单位选择逻辑"""
    print("\n🔧 测试单位选择逻辑...")
    
    # 创建模拟对象
    class MockFrame:
        def __init__(self):
            self.operations = []
        
        def locator(self, selector):
            self.operations.append(f"locator: {selector}")
            return MockLocator(selector)
        
        def get_by_role(self, role, **kwargs):
            self.operations.append(f"get_by_role: {role}, {kwargs}")
            return MockLocator(f"role:{role}")
    
    class MockLocator:
        def __init__(self, selector):
            self.selector = selector
            self.operations = []
        
        def count(self):
            # 模拟存在单位选择框
            if 'selectBatchAdd' in self.selector:
                return 1
            return 0
        
        def wait_for(self, **kwargs):
            self.operations.append(f"wait_for: {kwargs}")
            return self
        
        def click(self, **kwargs):
            self.operations.append(f"click: {kwargs}")
            return self
        
        def fill(self, value, **kwargs):
            self.operations.append(f"fill: {value}, {kwargs}")
            return self
        
        def press(self, key):
            self.operations.append(f"press: {key}")
            return self
        
        def get_by_role(self, role, **kwargs):
            return MockLocator(f"{self.selector}+role:{role}")
    
    class MockPage:
        def wait_for_timeout(self, timeout):
            print(f"  ⏳ 等待 {timeout}ms")
    
    # 测试字段列表
    test_fields = [
        "Assembled Product Depth",
        "Assembled Product Height", 
        "Assembled Product Width",
        "Assembled Product Weight",
        "Shipping Weight (lbs)"
    ]
    
    # 创建模拟的产品数据
    mock_product = {
        'Product Dimensions': '24 x 12 x 36 inches',
        'Item Weight': '8.5 pounds'
    }
    
    print("📦 测试产品数据:")
    for key, value in mock_product.items():
        print(f"  - {key}: {value}")
    
    # 模拟字段解析器
    listener = FormConfigListener()
    config = listener.load_config()
    if config:
        parser = FormFieldParser(config)
    else:
        print("⚠️ 使用模拟解析器")
        parser = None
    
    mock_frame = MockFrame()
    mock_page = MockPage()
    
    # 创建表单填充器
    if parser:
        form_filler = DynamicFormFiller(mock_frame, parser, mock_product, mock_page)
    else:
        # 模拟场景
        print("⚠️ 无法创建完整的表单填充器，仅测试单位选择逻辑")
        return True
    
    print(f"\n🧪 测试单位选择逻辑 (共{len(test_fields)}个字段):")
    
    for field_title in test_fields:
        print(f"\n  测试字段: {field_title}")
        
        # 重置操作记录
        mock_frame.operations = []
        
        try:
            # 测试单位选择处理
            form_filler._handle_unit_selection(field_title)
            
            # 显示操作序列
            print(f"    执行的操作:")
            for op in mock_frame.operations[-5:]:  # 显示最后5个操作
                print(f"      - {op}")
                
        except Exception as e:
            print(f"    ❌ 测试失败: {e}")
    
    return True

def test_dimension_extraction():
    """测试尺寸提取逻辑"""
    print("\n📏 测试尺寸提取逻辑...")
    
    # 创建模拟的表单填充器
    class MockFormFiller:
        def __init__(self):
            self.product_details = {
                'Product Dimensions': '15.7 x 9.8 x 4.3 inches',
                'Item Weight': '2.1 pounds'
            }
        
        def _extract_dimension_value(self, dimension_type):
            """模拟尺寸提取方法"""
            if 'Product Dimensions' not in self.product_details:
                return None
            
            dimensions_str = str(self.product_details['Product Dimensions'])
            parts = dimensions_str.split('x')
            
            if 'Depth' in dimension_type and len(parts) > 0:
                return parts[0].strip().split('"')[0]
            elif 'Width' in dimension_type and len(parts) > 1:
                return parts[1].strip().split('"')[0]  
            elif 'Height' in dimension_type and len(parts) > 2:
                return parts[2].strip().split('"')[0]
            
            return None
    
    mock_filler = MockFormFiller()
    
    print("📦 测试产品:")
    for key, value in mock_filler.product_details.items():
        print(f"  - {key}: {value}")
    
    # 测试尺寸提取
    dimension_fields = [
        "Assembled Product Depth",
        "Assembled Product Width", 
        "Assembled Product Height"
    ]
    
    print(f"\n📐 尺寸提取测试:")
    for field in dimension_fields:
        extracted_value = mock_filler._extract_dimension_value(field)
        print(f"  - {field}: {extracted_value}")
    
    return True

def test_complete_workflow():
    """测试完整的复合组件填充流程"""
    print("\n🔄 测试完整的复合组件填充流程...")
    
    # 使用真实的配置数据
    listener = FormConfigListener() 
    config = listener.load_config()
    
    if not config:
        print("⚠️ 需要真实的配置数据才能进行完整测试")
        return False
    
    parser = FormFieldParser(config)
    
    # 创建测试产品数据
    test_product = {
        'title': 'Premium Bamboo Storage Shelf',
        'Brand': 'EcoHome',
        'Product Dimensions': '24.5 x 11.8 x 35.2 inches',
        'Item Weight': '8.7 pounds',
        'Material': 'Bamboo'
    }
    
    print("📦 测试产品数据:")
    for key, value in test_product.items():
        print(f"  - {key}: {value}")
    
    # 创建增强的模拟对象，记录更多操作细节
    class EnhancedMockFrame:
        def __init__(self):
            self.operations = []
        
        def locator(self, selector):
            self.operations.append(f"🎯 定位元素: {selector}")
            return EnhancedMockLocator(selector, self.operations)
        
        def get_by_role(self, role, **kwargs):
            self.operations.append(f"🎭 按角色查找: {role} {kwargs}")
            return EnhancedMockLocator(f"role:{role}", self.operations)
    
    class EnhancedMockLocator:
        def __init__(self, selector, operations_log):
            self.selector = selector
            self.operations_log = operations_log
        
        def count(self):
            # 模拟复合组件存在单位选择框
            if 'selectBatchAdd' in self.selector and any(keyword in self.selector for keyword in ['Depth', 'Width', 'Height', 'Weight']):
                self.operations_log.append(f"  📊 {self.selector} 检测到单位选择框")
                return 1
            return 0
        
        def wait_for(self, **kwargs):
            self.operations_log.append(f"  ⏳ 等待元素: {kwargs}")
            return self
        
        def click(self, **kwargs):
            self.operations_log.append(f"  🖱️ 点击: {kwargs}")
            return self
        
        def fill(self, value, **kwargs):
            self.operations_log.append(f"  ✏️ 填充值: '{value}' {kwargs}")
            return self
        
        def press(self, key):
            self.operations_log.append(f"  ⌨️ 按键: {key}")
            return self
        
        def get_by_role(self, role, **kwargs):
            return EnhancedMockLocator(f"{self.selector}+{role}", self.operations_log)
    
    class EnhancedMockPage:
        def wait_for_timeout(self, timeout):
            print(f"      ⏱️ 页面等待 {timeout}ms")
    
    mock_frame = EnhancedMockFrame()
    mock_page = EnhancedMockPage()
    
    # 创建表单填充器
    form_filler = DynamicFormFiller(mock_frame, parser, test_product, mock_page)
    
    # 获取尺寸相关字段进行测试
    all_fields = parser.get_all_fields()
    dimension_fields = [f for f in all_fields if any(keyword in f['title'] for keyword in ['Assembled Product Depth', 'Assembled Product Width', 'Assembled Product Height', 'Assembled Product Weight'])]
    
    print(f"\n🧪 完整流程测试 ({len(dimension_fields)}个复合组件字段):")
    
    for field_config in dimension_fields[:4]:  # 测试前4个字段
        field_title = field_config['title']
        print(f"\n  📋 测试字段: {field_title}")
        
        # 重置操作日志
        mock_frame.operations = []
        
        try:
            # 1. 获取字段值
            field_value = form_filler._get_field_value(field_config)
            print(f"    📊 获取到值: {field_value}")
            
            # 2. 模拟填充过程
            if field_value is not None:
                print(f"    🔧 开始填充流程...")
                
                # 模拟文本输入
                input_selector = f"div[attrkey='{field_title}'] input[class='select2-input select2-default']"
                mock_frame.locator(input_selector).fill(str(field_value))
                
                focused_input = f"div[attrkey='{field_title}'] input[class='select2-input select2-focused']"
                mock_frame.locator(focused_input).press("Enter")
                
                # 3. 单位选择
                form_filler._handle_unit_selection(field_title)
                
                # 显示操作日志
                print(f"    📝 执行的操作:")
                for op in mock_frame.operations:
                    print(f"      {op}")
            else:
                print(f"    ⚠️ 未获取到值，跳过填充")
                
        except Exception as e:
            print(f"    ❌ 测试失败: {e}")
    
    return True

def main():
    print("🚀 复合组件单位选择功能测试")
    print("=" * 50)
    
    # 运行各项测试
    test_dimension_field_identification()
    test_unit_selection_logic() 
    test_dimension_extraction()
    test_complete_workflow()
    
    print("\n" + "=" * 50)
    print("🎉 测试完成！")
    
    print("\n💡 关键改进点:")
    print("1. 🔧 新增通用单位选择处理方法 _handle_unit_selection()")
    print("2. 📝 在 _fill_text_field() 中添加单位选择逻辑")
    print("3. ⏳ 增加等待时间确保元素稳定后再选择单位")
    print("4. 🎯 改进单位选择方法，支持多种单位选项")
    print("5. 📊 添加详细的操作日志，便于调试")
    
    print("\n🎯 预期效果:")
    print("- Assembled Product Depth: 数值 + 英寸单位")
    print("- Assembled Product Width: 数值 + 英寸单位") 
    print("- Assembled Product Height: 数值 + 英寸单位")
    print("- Assembled Product Weight: 数值 + 磅单位")

if __name__ == "__main__":
    main()
