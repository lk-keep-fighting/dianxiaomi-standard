#!/usr/bin/env python3
"""
测试新的auto_form_filler.py实现
验证与old.py中验证可行模式的兼容性
"""

import sys
import os

# 添加src目录到路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from auto_form_filler import (
    auto_fill_form_fields, 
    extract_dimensions_old_style,
    extract_weight_old_style,
    get_fallback_schema,
    load_form_schema,
    create_schema_based_mapping
)

def test_dimension_extraction():
    """测试尺寸提取功能 - 基于old.py验证可行的方法"""
    print("🧪 测试尺寸提取功能")
    print("=" * 50)
    
    # 测试数据 (模拟Amazon产品详情)
    test_product_details = {
        'Product Dimensions': '10.5 x 8.2 x 15.3 inches',
        'Item Weight': '25.4 pounds',
        'Brand': 'Test Brand',
        'Color': 'Black',
        'Material': 'Plastic'
    }
    
    # 测试尺寸提取（使用old.py验证可行的方法）
    dimensions = extract_dimensions_old_style(test_product_details)
    print(f"✅ 尺寸提取结果: {dimensions}")
    
    # 验证结果
    expected = {"depth": "10.5", "width": "8.2", "height": "15.3"}
    if dimensions == expected:
        print("✅ 尺寸提取测试通过")
    else:
        print(f"❌ 尺寸提取测试失败。期望: {expected}, 实际: {dimensions}")
    
    return dimensions == expected


def test_weight_extraction():
    """测试重量提取功能"""
    print("\n🧪 测试重量提取功能")
    print("=" * 50)
    
    test_product_details = {
        'Item Weight': '25.4 pounds',
        'Product Dimensions': '10.5 x 8.2 x 15.3 inches'
    }
    
    # 测试重量提取
    weight = extract_weight_old_style(test_product_details)
    print(f"✅ 重量提取结果: {weight}")
    
    # 验证结果
    expected_weight = "25.4"
    if weight == expected_weight:
        print("✅ 重量提取测试通过")
    else:
        print(f"❌ 重量提取测试失败。期望: {expected_weight}, 实际: {weight}")
    
    return weight == expected_weight


def test_schema_loading():
    """测试Schema加载功能"""
    print("\n🧪 测试Schema加载功能")
    print("=" * 50)
    
    # 测试加载form-json-schema.json
    schema = load_form_schema()
    print(f"✅ Schema类型: {type(schema)}")
    print(f"✅ Schema包含properties: {'properties' in schema}")
    
    # 测试fallback schema
    fallback = get_fallback_schema()
    print(f"✅ Fallback Schema包含field_mappings: {'field_mappings' in fallback}")
    print(f"✅ Fallback Schema包含fixed_values: {'fixed_values' in fallback}")
    print(f"✅ Fallback Schema包含compound_fields: {'compound_fields' in fallback}")
    
    # 如果新schema可用，测试映射创建
    if "properties" in schema:
        print("📋 使用新Schema格式")
        mapping_config = create_schema_based_mapping(schema)
    else:
        print("📋 使用Fallback Schema格式")
        mapping_config = fallback
    
    print(f"✅ 映射配置类型: {type(mapping_config)}")
    
    return True


def test_field_mappings():
    """测试字段映射配置"""
    print("\n🧪 测试字段映射配置")
    print("=" * 50)
    
    fallback_config = get_fallback_schema()
    
    # 测试字段映射
    field_mappings = fallback_config['field_mappings']
    print("📋 字段映射:")
    for source, target in field_mappings.items():
        print(f"  {source} -> {target}")
    
    # 测试固定值
    fixed_values = fallback_config['fixed_values']
    print("\n📋 固定值:")
    for field, value in fixed_values.items():
        print(f"  {field} = {value}")
    
    # 测试复合字段
    compound_fields = fallback_config['compound_fields']
    print("\n📋 复合字段:")
    for field, config in compound_fields.items():
        print(f"  {field}: {config}")
    
    return True


def test_old_py_compatibility():
    """测试与old.py中验证可行模式的兼容性"""
    print("\n🧪 测试与old.py的兼容性")
    print("=" * 50)
    
    # 模拟old.py中的测试数据
    test_product_details = {
        'Product Dimensions': '57.9 x 31.5 x 32.7 inches',
        'Item Weight': '70.7 pounds',
        'Brand': 'Lifestyle Solutions',
        'Color': 'Black',
        'Material': 'Microfiber',
        'Special Feature': 'Rolled Arms',
        'Style': 'Modern',
        'Indoor/Outdoor Usage': 'Indoor'
    }
    
    print("📋 测试产品详情:")
    for key, value in test_product_details.items():
        print(f"  {key}: {value}")
    
    # 测试各个组件
    print("\n🔧 测试尺寸提取...")
    dimensions = extract_dimensions_old_style(test_product_details)
    print(f"  提取的尺寸: {dimensions}")
    
    print("\n🔧 测试重量提取...")
    weight = extract_weight_old_style(test_product_details)
    print(f"  提取的重量: {weight}")
    
    # 验证与old.py模式的兼容性
    expected_depth = "57.9"
    expected_width = "31.5" 
    expected_height = "32.7"
    expected_weight = "70.7"
    
    compatibility_checks = [
        (dimensions['depth'] == expected_depth, f"Depth: {dimensions['depth']} == {expected_depth}"),
        (dimensions['width'] == expected_width, f"Width: {dimensions['width']} == {expected_width}"),
        (dimensions['height'] == expected_height, f"Height: {dimensions['height']} == {expected_height}"),
        (weight == expected_weight, f"Weight: {weight} == {expected_weight}")
    ]
    
    print("\n📊 兼容性检查结果:")
    all_passed = True
    for passed, description in compatibility_checks:
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"  {status}: {description}")
        if not passed:
            all_passed = False
    
    return all_passed


def test_main_integration():
    """测试主函数集成"""
    print("\n🧪 测试主函数集成 (模拟)")
    print("=" * 50)
    
    # 模拟测试数据
    mock_product_details = {
        'Brand': 'Test Brand',
        'Color': 'Test Color',
        'Product Dimensions': '10 x 20 x 30 inches',
        'Item Weight': '15.5 pounds',
        'Special Feature': 'Ergonomic Design',
        'Indoor/Outdoor Usage': 'Indoor'
    }
    
    print("📋 模拟产品详情:")
    for key, value in mock_product_details.items():
        print(f"  {key}: {value}")
    
    print("\n🔧 模拟调用auto_fill_form_fields...")
    print("  (实际调用需要Playwright frame对象)")
    
    # 这里只能模拟配置加载和数据处理
    try:
        schema = load_form_schema()
        if "properties" in schema:
            mapping_config = create_schema_based_mapping(schema)
        else:
            mapping_config = get_fallback_schema()
        
        print("  ✅ 配置加载成功")
        print("  ✅ 映射创建成功")
        
        # 测试数据提取
        dimensions = extract_dimensions_old_style(mock_product_details)
        weight = extract_weight_old_style(mock_product_details)
        
        print(f"  ✅ 尺寸提取: {dimensions}")
        print(f"  ✅ 重量提取: {weight}")
        
        return True
    except Exception as e:
        print(f"  ❌ 集成测试失败: {e}")
        return False


def main():
    """运行所有测试"""
    print("🚀 开始测试新的auto_form_filler.py实现")
    print("验证与old.py验证可行模式的兼容性")
    print("=" * 70)
    
    # 运行所有测试
    tests = [
        ("尺寸提取功能", test_dimension_extraction),
        ("重量提取功能", test_weight_extraction), 
        ("Schema加载功能", test_schema_loading),
        ("字段映射配置", test_field_mappings),
        ("old.py兼容性", test_old_py_compatibility),
        ("主函数集成", test_main_integration),
    ]
    
    results = []
    for test_name, test_func in tests:
        try:
            result = test_func()
            results.append((test_name, result, None))
        except Exception as e:
            results.append((test_name, False, str(e)))
    
    # 输出测试结果摘要
    print("\n" + "=" * 70)
    print("📊 测试结果摘要")
    print("=" * 70)
    
    passed_count = 0
    total_count = len(results)
    
    for test_name, passed, error in results:
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"{status}: {test_name}")
        if error:
            print(f"    错误: {error}")
        if passed:
            passed_count += 1
    
    print(f"\n📈 总体结果: {passed_count}/{total_count} 测试通过")
    
    if passed_count == total_count:
        print("🎉 所有测试通过！新实现与old.py验证可行模式完全兼容")
        return True
    else:
        print("⚠️ 部分测试失败，需要进一步调试")
        return False


if __name__ == "__main__":
    success = main()
    exit(0 if success else 1)
