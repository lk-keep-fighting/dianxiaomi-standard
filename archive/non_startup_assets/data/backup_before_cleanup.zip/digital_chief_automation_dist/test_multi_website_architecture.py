#!/usr/bin/env python3
"""
多网站架构完整性测试

测试内容：
1. 核心组件加载和初始化
2. 网站策略注册机制
3. 自动化引擎协调功能
4. 架构扩展性验证

运行方式：python test_multi_website_architecture.py
"""

import sys
import os

# 添加src目录到Python路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from typing import Dict, Any
from unittest.mock import Mock, MagicMock

def test_core_components():
    """测试核心组件导入和初始化"""
    print("🧪 测试核心组件...")
    
    try:
        # 测试核心组件导入
        from core.product_data import ProductData, BASE_FIELD_MAPPING
        from core.amazon_product_parser import AmazonProductParser
        from core.system_config import SYSTEM_CONFIG
        
        # 测试ProductData
        product_data = ProductData(
            title="测试产品",
            details={"Brand": "TestBrand", "Color": "Red"},
            weight_value="5.2"
        )
        
        assert product_data.has_valid_data(), "ProductData应该有有效数据"
        assert product_data.get_detail("Brand") == "TestBrand", "应该能获取品牌信息"
        
        # 测试字段映射
        form_field = BASE_FIELD_MAPPING.get_form_field("Brand")
        assert form_field == "Manufacturer Name", f"Brand应该映射到Manufacturer Name，实际得到: {form_field}"
        
        # 测试系统配置
        assert SYSTEM_CONFIG.get_timeout('short') == 5000, "短超时应该是5000ms"
        
        print("  ✅ 核心组件测试通过")
        return True
        
    except Exception as e:
        print(f"  ❌ 核心组件测试失败: {e}")
        return False

def test_website_strategy_base():
    """测试网站策略基类"""
    print("🧪 测试网站策略基类...")
    
    try:
        from websites.base.website_strategy import WebsiteStrategy
        from websites.base.form_filler_base import FormFillerBase
        
        # 创建测试策略实现
        class TestStrategy(WebsiteStrategy):
            def get_site_name(self) -> str:
                return "TestSite"
            
            def validate_environment(self, page) -> bool:
                return True
            
            def authenticate(self, page, context) -> bool:
                return True
            
            def navigate_to_form(self, page):
                return Mock()
            
            def fill_form(self, form_handle, product_data) -> Dict[str, Any]:
                return {'successful_fills': 1, 'failed_fills': 0}
            
            def get_field_mappings(self) -> Dict[str, str]:
                return {"Brand": "Manufacturer Name"}
        
        # 测试策略实例化
        strategy = TestStrategy()
        assert strategy.get_site_name() == "TestSite", "网站名称应该正确"
        assert strategy.validate_environment(None), "环境验证应该通过"
        assert strategy.authenticate(None, None), "认证应该成功"
        
        print("  ✅ 网站策略基类测试通过")
        return True
        
    except Exception as e:
        print(f"  ❌ 网站策略基类测试失败: {e}")
        return False

def test_automation_engine():
    """测试自动化引擎"""
    print("🧪 测试自动化引擎...")
    
    try:
        from automation_engine import AutomationEngine
        from websites.base.website_strategy import WebsiteStrategy
        
        # 创建引擎实例
        engine = AutomationEngine()
        
        # 创建测试策略
        class MockStrategy(WebsiteStrategy):
            def get_site_name(self) -> str:
                return "MockSite"
            
            def validate_environment(self, page) -> bool:
                return True
            
            def authenticate(self, page, context) -> bool:
                return True
            
            def navigate_to_form(self, page):
                return Mock()
            
            def fill_form(self, form_handle, product_data) -> Dict[str, Any]:
                return {
                    'successful_fills': 3,
                    'failed_fills': 0,
                    'total_attempts': 3,
                    'success_rate': 100.0
                }
            
            def get_field_mappings(self) -> Dict[str, str]:
                return {"Brand": "Manufacturer Name"}
        
        # 测试策略注册
        mock_strategy = MockStrategy()
        engine.register_strategy(mock_strategy)
        
        assert "MockSite" in engine.list_available_sites(), "MockSite应该在可用网站列表中"
        assert engine.get_strategy("MockSite") is not None, "应该能获取注册的策略"
        
        # 测试统计功能
        initial_stats = engine._get_execution_stats()
        assert initial_stats['total_runs'] == 0, "初始运行次数应该为0"
        
        engine.reset_stats()
        assert engine.stats['successful_runs'] == 0, "重置后成功次数应该为0"
        
        print("  ✅ 自动化引擎测试通过")
        return True
        
    except Exception as e:
        print(f"  ❌ 自动化引擎测试失败: {e}")
        return False

def test_form_filler_base():
    """测试表单填充基类"""
    print("🧪 测试表单填充基类...")
    
    try:
        from websites.base.form_filler_base import FormFillerBase
        from core.product_data import ProductData
        
        # 创建测试表单填充器
        class TestFormFiller(FormFillerBase):
            def fill_form(self, product_data: ProductData) -> Dict[str, Any]:
                # 模拟填充过程
                self.stats['total_attempts'] = 5
                self.stats['successful_fills'] = 4
                self.stats['failed_fills'] = 1
                
                return self.get_fill_stats()
        
        # 创建模拟表单句柄
        mock_form = Mock()
        mock_form.locator = Mock(return_value=Mock())
        
        # 测试表单填充器
        filler = TestFormFiller(mock_form)
        
        product_data = ProductData(
            title="测试产品",
            details={"Brand": "TestBrand"}
        )
        
        result = filler.fill_form(product_data)
        
        assert result['total_attempts'] == 5, "总尝试次数应该正确"
        assert result['successful_fills'] == 4, "成功次数应该正确"
        assert result['success_rate'] == 80.0, "成功率应该是80%"
        
        print("  ✅ 表单填充基类测试通过")
        return True
        
    except Exception as e:
        print(f"  ❌ 表单填充基类测试失败: {e}")
        return False

def test_architecture_integration():
    """测试架构整合"""
    print("🧪 测试架构整合...")
    
    try:
        from automation_engine import AUTOMATION_ENGINE
        from websites.base.website_strategy import WebsiteStrategy
        from core.product_data import ProductData
        
        # 创建多个测试策略
        class SiteA_Strategy(WebsiteStrategy):
            def get_site_name(self) -> str:
                return "SiteA"
            
            def validate_environment(self, page) -> bool:
                return "sitea.com" in str(page)
            
            def authenticate(self, page, context) -> bool:
                return True
            
            def navigate_to_form(self, page):
                return Mock()
            
            def fill_form(self, form_handle, product_data) -> Dict[str, Any]:
                return {'successful_fills': 2, 'failed_fills': 0}
            
            def get_field_mappings(self) -> Dict[str, str]:
                return {"Brand": "Manufacturer"}
        
        class SiteB_Strategy(WebsiteStrategy):
            def get_site_name(self) -> str:
                return "SiteB"
            
            def validate_environment(self, page) -> bool:
                return "siteb.com" in str(page)
            
            def authenticate(self, page, context) -> bool:
                return True
            
            def navigate_to_form(self, page):
                return Mock()
            
            def fill_form(self, form_handle, product_data) -> Dict[str, Any]:
                return {'successful_fills': 3, 'failed_fills': 1}
            
            def get_field_mappings(self) -> Dict[str, str]:
                return {"Brand": "Brand Name"}
        
        # 注册多个策略
        AUTOMATION_ENGINE.register_strategy(SiteA_Strategy())
        AUTOMATION_ENGINE.register_strategy(SiteB_Strategy())
        
        # 验证注册
        available_sites = AUTOMATION_ENGINE.list_available_sites()
        assert "SiteA" in available_sites, "SiteA应该在可用网站中"
        assert "SiteB" in available_sites, "SiteB应该在可用网站中"
        assert len(available_sites) >= 2, "至少应该有2个网站"
        
        # 测试策略获取
        site_a_strategy = AUTOMATION_ENGINE.get_strategy("SiteA")
        assert site_a_strategy is not None, "应该能获取SiteA策略"
        assert site_a_strategy.get_site_name() == "SiteA", "策略名称应该正确"
        
        # 测试不同策略的字段映射差异
        mapping_a = site_a_strategy.get_field_mappings()
        mapping_b = AUTOMATION_ENGINE.get_strategy("SiteB").get_field_mappings()
        
        assert mapping_a["Brand"] != mapping_b["Brand"], "不同网站的映射应该不同"
        
        print("  ✅ 架构整合测试通过")
        return True
        
    except Exception as e:
        print(f"  ❌ 架构整合测试失败: {e}")
        return False

def test_extensibility():
    """测试架构扩展性"""
    print("🧪 测试架构扩展性...")
    
    try:
        from automation_engine import AutomationEngine
        from websites.base.website_strategy import WebsiteStrategy
        from websites.base.form_filler_base import FormFillerBase
        
        # 创建新的引擎实例用于扩展测试
        test_engine = AutomationEngine()
        
        # 模拟添加新网站的过程
        class NewSiteStrategy(WebsiteStrategy):
            def get_site_name(self) -> str:
                return "NewEcommerceSite"
            
            def validate_environment(self, page) -> bool:
                return True
            
            def authenticate(self, page, context) -> bool:
                return True
            
            def navigate_to_form(self, page):
                return Mock()
            
            def fill_form(self, form_handle, product_data) -> Dict[str, Any]:
                return {'successful_fills': 5, 'failed_fills': 0}
            
            def get_field_mappings(self) -> Dict[str, str]:
                return {
                    "Brand": "Vendor",
                    "Color": "Product Color",
                    "Weight": "Item Weight"
                }
        
        # 测试动态添加新网站
        new_strategy = NewSiteStrategy()
        test_engine.register_strategy(new_strategy)
        
        # 验证扩展
        assert "NewEcommerceSite" in test_engine.list_available_sites(), "新网站应该被注册"
        
        # 测试新网站的独特映射
        new_mappings = new_strategy.get_field_mappings()
        assert new_mappings["Brand"] == "Vendor", "新网站应该有独特的字段映射"
        
        # 验证不影响现有网站
        original_sites = test_engine.list_available_sites()
        test_engine.register_strategy(NewSiteStrategy())  # 重复注册应该覆盖
        new_sites = test_engine.list_available_sites()
        
        assert len(original_sites) == len(new_sites), "重复注册不应该增加网站数量"
        
        print("  ✅ 架构扩展性测试通过")
        return True
        
    except Exception as e:
        print(f"  ❌ 架构扩展性测试失败: {e}")
        return False

def main():
    """主测试函数"""
    print("🌟 多网站架构完整性测试")
    print("="*50)
    
    tests = [
        ("核心组件", test_core_components),
        ("网站策略基类", test_website_strategy_base),
        ("自动化引擎", test_automation_engine),
        ("表单填充基类", test_form_filler_base),
        ("架构整合", test_architecture_integration),
        ("架构扩展性", test_extensibility)
    ]
    
    passed_tests = 0
    total_tests = len(tests)
    
    for test_name, test_func in tests:
        print(f"\n🔄 运行 {test_name} 测试...")
        try:
            if test_func():
                passed_tests += 1
        except Exception as e:
            print(f"  ❌ {test_name} 测试异常: {e}")
    
    # 打印测试总结
    print("\n" + "="*50)
    print("📊 测试结果总结")
    print("="*50)
    print(f"✅ 通过: {passed_tests}")
    print(f"❌ 失败: {total_tests - passed_tests}")
    print(f"📈 成功率: {passed_tests/total_tests*100:.1f}%")
    
    if passed_tests == total_tests:
        print("\n🎉 多网站架构测试全部通过！")
        print("✅ 架构设计合理，支持多网站扩展")
        print("✅ 核心组件功能正常")
        print("✅ 策略模式实现正确")
        print("✅ 系统具备良好的扩展性")
    else:
        print(f"\n⚠️ 有 {total_tests - passed_tests} 个测试失败，需要修复")
        return 1
    
    return 0

if __name__ == "__main__":
    exit(main())
