#!/usr/bin/env python3
"""
测试动态表单填充方案
"""
import sys
import os

# 添加src目录到Python路径
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from form_config_listener import FormConfigListener, FormFieldParser

def test_config_loading():
    """测试配置文件加载"""
    print("🧪 测试配置文件加载...")
    
    listener = FormConfigListener()
    config = listener.load_config()
    
    if config:
        print("✅ 配置文件加载成功")
        print(f"📅 时间戳: {config.get('timestamp')}")
        print(f"🔗 API URL: {config.get('api_url')}")
        
        # 测试字段解析
        try:
            parser = FormFieldParser(config)
            parser.print_fields_summary()
            
            # 获取前几个字段的详细信息
            required_fields = parser.get_all_required_fields()
            print(f"\n📝 前5个必填字段详情:")
            for i, field in enumerate(required_fields[:5]):
                print(f"  {i+1}. {field['name']}")
                print(f"     标题: {field['title']}")
                print(f"     类型: {field['input_type']}")
                print(f"     必填: {field['required']}")
                print(f"     数据类型: {field['data_type']}")
                print(f"     值类型: {field['value_type']}")
                print()
            
            print("✅ 字段解析测试通过")
            
        except Exception as e:
            print(f"❌ 字段解析测试失败: {e}")
            
    else:
        print("❌ 未找到配置文件")
        print("💡 请先运行 main-table-model.py 并完成一次表单操作以捕获API数据")

def test_sample_product_data():
    """测试样例产品数据映射"""
    print("\n🛍️ 测试样例产品数据映射...")
    
    # 模拟产品详情数据
    sample_product = {
        'title': 'Sample Wireless Bluetooth Headphones',
        'Brand': 'TechBrand',
        'Color': 'Black',
        'Product Dimensions': '8.5 x 7.2 x 3.1 inches',
        'Item Weight': '1.2 pounds',
        'Material': 'Plastic',
        'Style': 'Over-Ear'
    }
    
    print("📦 样例产品数据:")
    for key, value in sample_product.items():
        print(f"  {key}: {value}")
    
    # 如果有配置文件，测试映射
    listener = FormConfigListener()
    config = listener.load_config()
    
    if config:
        try:
            from dynamic_form_filler import DynamicFormFiller
            
            parser = FormFieldParser(config)
            
            # 创建一个模拟的frame对象来测试映射逻辑
            class MockFrame:
                def wait_for_timeout(self, timeout):
                    pass
                @property
                def page(self):
                    class MockPage:
                        def wait_for_timeout(self, timeout):
                            pass
                    return MockPage()
            
            mock_frame = MockFrame()
            filler = DynamicFormFiller(mock_frame, parser, sample_product)
            
            # 测试字段值获取
            required_fields = parser.get_all_required_fields()
            print(f"\n🔍 字段值映射测试 (前5个字段):")
            
            for i, field_config in enumerate(required_fields[:5]):
                field_value = filler._get_field_value(field_config)
                print(f"  {i+1}. {field_config['title']}")
                print(f"     映射值: {field_value}")
                print(f"     输入类型: {field_config['input_type']}")
                print()
            
            print("✅ 产品数据映射测试通过")
            
        except Exception as e:
            print(f"❌ 产品数据映射测试失败: {e}")
    else:
        print("⚠️ 跳过映射测试（无配置文件）")

def main():
    print("🚀 动态表单填充方案测试")
    print("=" * 50)
    
    test_config_loading()
    test_sample_product_data()
    
    print("\n" + "=" * 50)
    print("🎉 测试完成！")
    
    print("\n💡 使用说明:")
    print("1. 运行 python src/main-table-model.py")
    print("2. 在表单页面触发API调用以捕获配置数据")  
    print("3. 新的动态填充引擎将自动使用API配置进行智能表单填充")
    print("4. 如果动态填充失败，系统会自动回退到基础填充模式")

if __name__ == "__main__":
    main()
