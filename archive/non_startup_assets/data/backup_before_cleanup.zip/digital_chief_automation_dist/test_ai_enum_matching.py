#!/usr/bin/env python3
"""
AI枚举匹配功能综合测试
验证AI根据产品上下文选择最合适枚举值的能力
"""
import sys
import os
import json

# 添加src目录到Python路径
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from ai_enum_matcher import AIEnumMatcher
from field_defaults_manager import FieldDefaultsManager
from form_config_listener import FormConfigListener, FormFieldParser
from dynamic_form_filler import DynamicFormFiller

def test_ai_enum_matcher_basic():
    """测试AI枚举匹配器基础功能"""
    print("🧪 测试AI枚举匹配器基础功能...")
    
    matcher = AIEnumMatcher()
    
    if not matcher.is_available():
        print("⚠️ AI枚举匹配器不可用（需要设置OPENAI_API_KEY）")
        return False
    
    print("✅ AI枚举匹配器可用")
    
    # 测试简单枚举匹配
    field_config = {
        'title': 'Age Group',
        'description': 'A general grouping of ages into commonly used demographic labels',
        'input_type': 'select'
    }
    
    product_details = {
        'title': 'Kids Study Desk Chair with Wheels',
        'Key Features': ['Perfect for children ages 6-12', 'Kid-friendly design', 'Easy to adjust height'],
        'Brand': 'KidsDesk'
    }
    
    enum_options = ['Teen', 'Tween', 'Toddler', 'Adult', 'Child']
    
    result = matcher.match_enum_value(field_config, product_details, enum_options)
    
    if result:
        selected_value, confidence = result
        print(f"✅ AI匹配结果: {selected_value} (置信度: {confidence:.2f})")
        return True
    else:
        print("❌ AI匹配失败")
        return False

def test_color_category_matching():
    """测试颜色类别匹配"""
    print("\n🧪 测试颜色类别匹配...")
    
    matcher = AIEnumMatcher()
    
    if not matcher.is_available():
        print("⚠️ 跳过测试（AI不可用）")
        return True
    
    test_cases = [
        {
            'product': {
                'title': 'Black Leather Executive Chair',
                'Color': 'Black',
                'Material': 'Leather'
            },
            'expected_color': 'Black'
        },
        {
            'product': {
                'title': 'Multi-colored Rainbow Storage Chair', 
                'Color': 'Red, Blue, Yellow',
                'Key Features': ['Multiple colors', 'Bright rainbow design']
            },
            'expected_color': 'Multicolor'
        },
        {
            'product': {
                'title': 'Natural Wood Office Chair',
                'Material': 'Natural Bamboo Wood',
                'Color': 'Natural'
            },
            'expected_color': 'Brown'
        }
    ]
    
    field_config = {
        'title': 'Color Category',
        'description': 'Select the color from a short list that best describes the general color(s) of the item',
        'input_type': 'select'
    }
    
    enum_options = [
        'Blue', 'Brown', 'Gold', 'Gray', 'Purple', 'Clear', 'Yellow',
        'Off-White', 'Multicolor', 'Black', 'Beige', 'Pink', 'Orange',
        'Green', 'White', 'Red', 'Silver', 'Bronze'
    ]
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n📋 测试 {i}: {test_case['product']['title']}")
        
        result = matcher.match_enum_value(field_config, test_case['product'], enum_options)
        
        if result:
            selected_value, confidence = result
            expected = test_case['expected_color']
            
            status = "✅" if selected_value == expected else "⚠️"
            print(f"   {status} 匹配结果: {selected_value} (期望: {expected}, 置信度: {confidence:.2f})")
            
            if selected_value != expected:
                print(f"      💭 AI选择了不同但可能合理的颜色")
        else:
            print(f"   ❌ 匹配失败")
    
    return True

def test_furniture_type_matching():
    """测试家具类型匹配"""
    print("\n🧪 测试家具类型匹配...")
    
    matcher = AIEnumMatcher()
    
    if not matcher.is_available():
        print("⚠️ 跳过测试（AI不可用）")
        return True
    
    field_config = {
        'title': 'Desk Chair Type',
        'description': 'This indicates the type of desk chair',
        'input_type': 'select'
    }
    
    enum_options = [
        'Active Chairs', 'Office Chairs', 'Conference Chairs', 'Executive Chairs',
        'Drafting Chairs', 'Gaming Chairs', 'Manager\'s Chairs', 'Task Chairs',
        'Banker\'s Chairs', 'Stenographer Chairs', 'Kneeling Chairs'
    ]
    
    test_cases = [
        {
            'product': {
                'title': 'High-Back Executive Leather Chair',
                'Key Features': ['Premium leather upholstery', 'Executive style', 'High back design'],
                'Material': 'Leather'
            },
            'expected_type': 'Executive Chairs'
        },
        {
            'product': {
                'title': 'RGB Gaming Chair with LED Lights',
                'Key Features': ['Gaming ergonomics', 'RGB lighting', 'Racing style'],
                'Brand': 'GameMaster'
            },
            'expected_type': 'Gaming Chairs'
        },
        {
            'product': {
                'title': 'Adjustable Height Drafting Stool',
                'Key Features': ['Extra tall for drafting tables', 'Footrest ring', 'Height adjustable'],
                'Style': 'Drafting'
            },
            'expected_type': 'Drafting Chairs'
        }
    ]
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n📋 测试 {i}: {test_case['product']['title']}")
        
        result = matcher.match_enum_value(field_config, test_case['product'], enum_options)
        
        if result:
            selected_value, confidence = result
            expected = test_case['expected_type']
            
            status = "✅" if selected_value == expected else "⚠️"
            print(f"   {status} 匹配结果: {selected_value} (期望: {expected}, 置信度: {confidence:.2f})")
        else:
            print(f"   ❌ 匹配失败")
    
    return True

def test_assembly_required_matching():
    """测试组装要求匹配"""
    print("\n🧪 测试组装要求匹配...")
    
    matcher = AIEnumMatcher()
    
    if not matcher.is_available():
        print("⚠️ 跳过测试（AI不可用）")
        return True
    
    field_config = {
        'title': 'Is Assembly Required',
        'description': 'Is product unassembled and must be put together before use?',
        'input_type': 'select'
    }
    
    enum_options = ['Yes', 'No']
    
    test_cases = [
        {
            'product': {
                'title': 'Ready-to-Use Office Chair',
                'Key Features': ['Pre-assembled', 'Ready to use out of box', 'No assembly needed'],
                'Assembly Required': 'No'
            },
            'expected': 'No'
        },
        {
            'product': {
                'title': 'DIY Assembly Desk Chair Kit',
                'Key Features': ['Some assembly required', 'Instructions included', 'Easy 30-minute setup'],
                'Assembly Required': 'Yes'
            },
            'expected': 'Yes'
        },
        {
            'product': {
                'title': 'Ergonomic Task Chair - Assembly Required',
                'Key Features': ['Ergonomic design', 'Tool-free assembly', 'Assembly time: 15 minutes']
            },
            'expected': 'Yes'
        }
    ]
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n📋 测试 {i}: {test_case['product']['title']}")
        
        result = matcher.match_enum_value(field_config, test_case['product'], enum_options)
        
        if result:
            selected_value, confidence = result
            expected = test_case['expected']
            
            status = "✅" if selected_value == expected else "❌"
            print(f"   {status} 匹配结果: {selected_value} (期望: {expected}, 置信度: {confidence:.2f})")
        else:
            print(f"   ❌ 匹配失败")
    
    return True

def test_confidence_threshold():
    """测试置信度阈值功能"""
    print("\n🧪 测试置信度阈值功能...")
    
    matcher = AIEnumMatcher()
    
    # 测试不同字段的置信度阈值
    test_fields = [
        ('Age Group', 0.8),  # 关键字段
        ('Color Category', 0.6),  # 描述性字段
        ('Desk Chair Type', 0.6),  # 描述性字段
        ('Is Assembly Required', 0.8),  # 关键字段
        ('Unknown Field', 0.7)  # 默认阈值
    ]
    
    print("📏 置信度阈值测试:")
    for field_title, expected_threshold in test_fields:
        actual_threshold = matcher.get_enum_confidence_threshold(field_title)
        status = "✅" if actual_threshold == expected_threshold else "❌"
        print(f"   {status} {field_title}: {actual_threshold} (期望: {expected_threshold})")
    
    return True

def test_integration_with_defaults_manager():
    """测试与默认值管理器的集成"""
    print("\n🧪 测试与默认值管理器的集成...")
    
    defaults_manager = FieldDefaultsManager()
    
    if not defaults_manager.ai_enum_matcher or not defaults_manager.ai_enum_matcher.is_available():
        print("⚠️ 跳过测试（AI不可用）")
        return True
    
    # 创建测试字段配置
    test_field_configs = [
        {
            'title': 'Age Group',
            'input_type': 'select',
            'description': 'A general grouping of ages',
            'items': {
                'enum': ['Teen', 'Tween', 'Toddler', 'Adult', 'Child']
            }
        },
        {
            'title': 'Is Assembly Required',
            'input_type': 'select', 
            'description': 'Is product unassembled',
            'enum': ['Yes', 'No']
        }
    ]
    
    # 创建测试产品
    test_product = {
        'title': 'Kids Study Chair - Easy Assembly',
        'Key Features': ['Perfect for children', 'Simple 15-minute assembly', 'Ages 5-10'],
        'Assembly Required': 'Yes'
    }
    
    context = {
        'category': 'furniture',
        'product_details': test_product
    }
    
    print("📋 批量AI枚举推荐测试:")
    recommendations = defaults_manager.get_ai_enum_recommendations(test_field_configs, test_product, context)
    
    for field_title, (value, confidence) in recommendations.items():
        threshold = defaults_manager.ai_enum_matcher.get_enum_confidence_threshold(field_title)
        status = "✅" if confidence >= threshold else "⚠️"
        print(f"   {status} {field_title}: {value} (置信度: {confidence:.2f}, 阈值: {threshold})")
    
    return True

def test_integration_with_form_filler():
    """测试与表单填充器的集成"""
    print("\n🧪 测试与表单填充器的集成...")
    
    # 加载真实配置
    listener = FormConfigListener()
    config = listener.load_config()
    
    if not config:
        print("⚠️ 需要表单配置才能进行集成测试")
        return False
    
    parser = FormFieldParser(config)
    
    # 创建测试产品
    test_product = {
        'title': 'Premium Gaming Chair with RGB',
        'Brand': 'GamerPro',
        'Color': 'Black and Red',
        'Key Features': ['RGB lighting', 'Gaming ergonomics', 'Easy assembly required'],
        'Assembly Required': 'Yes'
    }
    
    # 模拟表单填充器
    class MockFrame:
        def locator(self, selector):
            return MockLocator()
        def get_by_role(self, role, **kwargs):
            return MockLocator()
    
    class MockLocator:
        def fill(self, value, **kwargs):
            pass
        def click(self, **kwargs):
            pass
        def press(self, key):
            pass
        def wait_for(self, **kwargs):
            pass
        def count(self):
            return 0
    
    mock_frame = MockFrame()
    
    # 创建表单填充器（启用AI）
    form_filler = DynamicFormFiller(mock_frame, parser, test_product, None, True)
    
    # 获取枚举字段进行测试
    all_fields = parser.get_all_fields()
    enum_fields = [f for f in all_fields if f.get('input_type') == 'select'][:5]
    
    print(f"📋 测试前 {len(enum_fields)} 个枚举字段:")
    
    for field in enum_fields:
        field_title = field['title']
        print(f"\n  🔍 测试字段: {field_title}")
        
        # 获取字段值（包括AI枚举匹配）
        field_value = form_filler._get_field_value(field)
        
        if field_value is not None:
            print(f"     ✅ 获取值: '{field_value}'")
        else:
            print(f"     ⚪ 无匹配值")
    
    return True

def test_edge_cases():
    """测试边界情况"""
    print("\n🧪 测试边界情况...")
    
    matcher = AIEnumMatcher()
    
    if not matcher.is_available():
        print("⚠️ 跳过测试（AI不可用）")
        return True
    
    # 测试空枚举选项
    result = matcher.match_enum_value(
        {'title': 'Test Field', 'description': 'Test'},
        {'title': 'Test Product'},
        []
    )
    assert result is None, "空枚举选项应该返回None"
    print("✅ 空枚举选项处理正确")
    
    # 测试单选项枚举
    result = matcher.match_enum_value(
        {'title': 'Single Option', 'description': 'Only one choice'},
        {'title': 'Any Product'},
        ['Only Option']
    )
    if result:
        selected_value, confidence = result
        assert selected_value == 'Only Option', "单选项应该直接选中"
        print(f"✅ 单选项处理正确: {selected_value} (置信度: {confidence:.2f})")
    
    # 测试无相关信息的产品
    result = matcher.match_enum_value(
        {'title': 'Color Category', 'description': 'Select color'},
        {'title': 'Mysterious Product'},  # 没有颜色信息
        ['Red', 'Blue', 'Green']
    )
    if result:
        selected_value, confidence = result
        print(f"⚠️ 无相关信息仍有匹配: {selected_value} (置信度: {confidence:.2f})")
    else:
        print("✅ 无相关信息正确返回None")
    
    return True

def main():
    """主测试函数"""
    print("🚀 AI枚举匹配功能综合测试")
    print("=" * 60)
    
    test_results = {}
    
    # 运行各项测试
    test_functions = [
        ("基础功能", test_ai_enum_matcher_basic),
        ("颜色类别匹配", test_color_category_matching),
        ("家具类型匹配", test_furniture_type_matching),
        ("组装要求匹配", test_assembly_required_matching),
        ("置信度阈值", test_confidence_threshold),
        ("默认值管理器集成", test_integration_with_defaults_manager),
        ("表单填充器集成", test_integration_with_form_filler),
        ("边界情况", test_edge_cases)
    ]
    
    for test_name, test_func in test_functions:
        try:
            print(f"\n{'='*60}")
            result = test_func()
            test_results[test_name] = "✅ 通过" if result else "⚠️ 部分问题"
        except Exception as e:
            test_results[test_name] = f"❌ 失败: {e}"
            print(f"❌ 测试失败: {e}")
    
    # 显示测试摘要
    print(f"\n{'='*60}")
    print("🎉 测试摘要")
    print("=" * 60)
    
    for test_name, result in test_results.items():
        print(f"{result} {test_name}")
    
    passed_count = sum(1 for result in test_results.values() if "✅" in result)
    total_count = len(test_results)
    
    print(f"\n📊 总体结果: {passed_count}/{total_count} 项测试通过")
    
    print(f"\n💡 AI枚举匹配系统特性:")
    print("1. 🤖 基于GPT-3.5-turbo的智能枚举值选择")
    print("2. 📊 产品上下文理解和分析能力")
    print("3. 🎯 字段描述和枚举选项的语义匹配")
    print("4. 📏 可配置的置信度阈值体系")
    print("5. 🔄 批量枚举匹配优化")
    print("6. 🔗 与默认值系统的无缝集成")
    print("7. ⚡ 智能后备策略和错误处理")
    print("8. 📝 详细的匹配推理日志")
    
    print(f"\n🎯 实际应用效果:")
    print("- 根据产品特征智能选择Age Group (Child/Adult/Teen)")
    print("- 基于颜色描述自动匹配Color Category")
    print("- 通过产品类型推断Desk Chair Type")
    print("- 根据组装信息判断Is Assembly Required")
    print("- 大幅减少枚举字段的手动选择工作量")

if __name__ == "__main__":
    main()
