#!/usr/bin/env python3
"""
测试AI智能表单映射功能
"""
import sys
import os

# 添加src目录到Python路径
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from form_config_listener import FormConfigListener, FormFieldParser
from dynamic_form_filler import DynamicFormFiller
from ai_form_mapper import AIFormMapper

def test_ai_mapping_standalone():
    """测试AI映射助手独立功能"""
    print("🧪 测试AI映射助手独立功能...")
    
    # 复杂的产品数据，包含需要智能分析的信息
    complex_product = {
        'title': 'SONGMICS Bamboo 3-Tier Corner Shelf Unit, Plant Stand with Adjustable Shelves',
        'Brand': 'SONGMICS',
        'Color': 'Natural Bamboo',
        'Product Dimensions': '11.8 x 11.8 x 32.3 inches',
        'Item Weight': '4.85 pounds',
        'Material': 'Bamboo',
        'Mounting Type': 'Freestanding',
        'Shelf Type': 'Corner Shelf',
        'Shape': 'Square',
        'Assembly Required': 'Yes',
        'Room Type': 'Living Room, Bedroom, Bathroom',
        'Style': 'Modern, Minimalist',
        'Care Instructions': 'Wipe Clean',
        'Water Resistance Level': 'Water Resistant'
    }
    
    print("📦 复杂产品数据:")
    for key, value in complex_product.items():
        print(f"  - {key}: {value}")
    
    # 模拟表单字段
    form_fields = [
        {'name': 'productName', 'title': 'Product Name', 'required': True, 'data_type': 'string'},
        {'name': 'brand', 'title': 'Brand Name', 'required': True, 'data_type': 'string'},
        {'name': 'color', 'title': 'Color', 'required': True, 'data_type': 'string'},
        {'name': 'material', 'title': 'Material', 'required': False, 'data_type': 'string'},
        {'name': 'assembledProductHeight', 'title': 'Assembled Product Height', 'required': True, 'data_type': 'number'},
        {'name': 'assembledProductWidth', 'title': 'Assembled Product Width', 'required': True, 'data_type': 'number'},
        {'name': 'assembledProductDepth', 'title': 'Assembled Product Depth', 'required': True, 'data_type': 'number'},
        {'name': 'shippingWeight', 'title': 'Shipping Weight (lbs)', 'required': True, 'data_type': 'number'},
        {'name': 'isAssemblyRequired', 'title': 'Is Assembly Required', 'required': True, 'value_type': 'boolean'},
        {'name': 'recommendedLocations', 'title': 'Recommended Locations', 'required': False, 'data_type': 'string'},
        {'name': 'careInstructions', 'title': 'Care Instructions', 'required': False, 'data_type': 'string'}
    ]
    
    print(f"\n📋 目标表单字段 ({len(form_fields)}个):")
    for field in form_fields:
        required_mark = " [必填]" if field.get('required') else ""
        print(f"  - {field['title']}{required_mark}")
    
    # 创建AI映射器并分析
    ai_mapper = AIFormMapper()
    
    if ai_mapper.api_key:
        result = ai_mapper.analyze_product_for_form_fields(complex_product, form_fields)
        ai_mapper.print_analysis_summary(result)
        
        # 分析结果统计
        mappings = result.get('mappings', {})
        total_fields = len(form_fields)
        mapped_fields = len(mappings)
        high_confidence_fields = len([m for m in mappings.values() if m.get('confidence', 0) >= 0.8])
        
        print(f"\n📊 AI分析统计:")
        print(f"  总字段数: {total_fields}")
        print(f"  成功映射: {mapped_fields} ({mapped_fields/total_fields*100:.1f}%)")
        print(f"  高置信度: {high_confidence_fields} ({high_confidence_fields/total_fields*100:.1f}%)")
        
        return True
    else:
        print("⚠️ API密钥未配置，跳过AI测试")
        return False

def test_integrated_ai_form_filler():
    """测试集成AI功能的表单填充器"""
    print("\n🔗 测试集成AI功能的表单填充器...")
    
    # 加载真实的表单配置
    listener = FormConfigListener()
    config = listener.load_config()
    
    if not config:
        print("⚠️ 未找到表单配置文件，请先运行主程序捕获API数据")
        return False
    
    parser = FormFieldParser(config)
    
    # 使用测试产品数据
    test_product = {
        'title': 'Premium Bamboo Desk Organizer with Multiple Compartments',
        'Brand': 'EcoOffice',
        'Color': 'Natural',
        'Product Dimensions': '15.7 x 9.8 x 4.3 inches',
        'Item Weight': '2.1 pounds',
        'Material': 'Bamboo',
        'Mounting Type': 'Freestanding',
        'Assembly Required': 'No',
        'Style': 'Modern'
    }
    
    print("📦 测试产品数据:")
    for key, value in test_product.items():
        print(f"  - {key}: {value}")
    
    # 创建模拟frame和page对象
    class MockFrame:
        def locator(self, selector):
            return MockLocator()
        def get_by_role(self, role, **kwargs):
            return MockLocator()
    
    class MockLocator:
        def fill(self, value, **kwargs):
            pass
        def click(self, **kwargs):
            pass
        def press(self, key):
            pass
        def get_by_role(self, role, **kwargs):
            return MockLocator()
    
    class MockPage:
        def wait_for_timeout(self, timeout):
            pass
    
    # 创建集成AI的表单填充器
    print("\n🤖 创建集成AI的表单填充器...")
    mock_frame = MockFrame()
    mock_page = MockPage()
    
    # 测试启用AI的情况
    form_filler = DynamicFormFiller(mock_frame, parser, test_product, mock_page, use_ai=True)
    
    # 获取必填字段进行测试
    required_fields = parser.get_all_required_fields()[:5]  # 只测试前5个字段
    
    print(f"\n🧪 测试AI字段值获取 (前{len(required_fields)}个必填字段):")
    for field_config in required_fields:
        field_value = form_filler._get_field_value(field_config)
        field_title = field_config['title']
        
        if field_value is not None:
            print(f"  ✅ {field_title}: {field_value}")
        else:
            print(f"  ⚠️ {field_title}: 未获取到值")
    
    return True

def show_configuration_guide():
    """显示配置指南"""
    print("\n📋 AI功能配置指南:")
    print("=" * 50)
    
    print("\n1. 设置API密钥:")
    print("   export OPENAI_API_KEY='your-api-key-here'")
    print("   # 或者在脚本中直接设置")
    
    print("\n2. 支持的API服务:")
    print("   - OpenAI官方API")
    print("   - Azure OpenAI Service")
    print("   - 其他OpenAI兼容的API服务")
    
    print("\n3. 自定义API端点:")
    print("   export OPENAI_BASE_URL='https://your-custom-endpoint.com/v1'")
    
    print("\n4. 配置文件:")
    print("   复制 .env.example 为 .env 并编辑")
    
    print("\n5. AI功能特点:")
    print("   - 智能字段映射和值推断")
    print("   - 自动缓存分析结果")
    print("   - 可配置置信度阈值")
    print("   - 优雅降级到传统映射")
    
    print("\n6. 成本控制:")
    print("   - 结果缓存减少重复调用")
    print("   - 可通过 use_ai=False 禁用AI功能")
    print("   - 支持本地API服务")

def main():
    print("🚀 AI智能表单映射功能测试")
    print("=" * 50)
    
    # 检查API密钥配置
    api_key = os.getenv("OPENAI_API_KEY")
    if api_key:
        print(f"✅ 检测到API密钥配置 (***{api_key[-4:]})")
        
        # 运行AI独立测试
        ai_test_success = test_ai_mapping_standalone()
        
        if ai_test_success:
            # 运行集成测试
            test_integrated_ai_form_filler()
        
    else:
        print("❌ 未检测到API密钥配置")
        show_configuration_guide()
    
    print("\n" + "=" * 50)
    print("🎉 测试完成！")
    
    print("\n💡 使用说明:")
    print("1. 配置API密钥后，AI功能将自动启用")
    print("2. AI会分析产品数据并智能推荐表单字段值")
    print("3. 支持复杂的数据转换和综合分析")
    print("4. 具有缓存机制，避免重复API调用")
    print("5. 如果AI分析失败，会自动回退到传统映射")

if __name__ == "__main__":
    main()
