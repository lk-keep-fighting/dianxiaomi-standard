export DC_USERNAME=''
export DC_PASSWORD=''
python main.py
