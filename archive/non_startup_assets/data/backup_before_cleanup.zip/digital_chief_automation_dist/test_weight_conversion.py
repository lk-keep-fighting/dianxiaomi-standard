#!/usr/bin/env python3
"""
测试重量转换功能
"""

def convert_weight_to_grams(weight_str: str) -> str:
    """
    将重量从磅转换为克，并移除单位
    
    Args:
        weight_str: 重量字符串，如 "39.68 Pounds" 或 "39.68"
        
    Returns:
        str: 转换后的克数，如 "17993"
    """
    import re
    
    try:
        if not weight_str:
            return "10"
        
        # 提取数字部分
        weight_match = re.search(r'([0-9.]+)', str(weight_str))
        if not weight_match:
            return "10"
        
        weight_pounds = float(weight_match.group(1))
        
        # 1磅 = 453.592克
        weight_grams = weight_pounds * 453.592
        
        # 返回整数克数
        return str(int(round(weight_grams)))
        
    except Exception as e:
        print(f"⚠️ 重量转换失败: {e}")
        return "10"


def test_weight_conversion():
    """测试重量转换功能"""
    test_cases = [
        "39.68 Pounds",
        "39.68",
        "5.2 pounds", 
        "10 lbs",
        "2.5",
        "",
        "invalid",
        "0.5 Pounds"
    ]
    
    print("🔍 重量转换测试")
    print("="*50)
    
    for test_weight in test_cases:
        result = convert_weight_to_grams(test_weight)
        print(f"输入: '{test_weight}' → 输出: {result}g")
    
    print("="*50)
    print("✅ 测试完成")


if __name__ == "__main__":
    test_weight_conversion()