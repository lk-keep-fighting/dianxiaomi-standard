#!/usr/bin/env python3
"""
选择框选项匹配修复测试
验证中英文混合选项的匹配能力
"""
import sys
import os

# 添加src目录到Python路径
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from dynamic_form_filler import DynamicFormFiller

# 创建模拟的表单填充器 - 在全局范围定义以便所有测试函数都可以访问
class MockFormFiller:
    def _generate_option_variants(self, value: str):
        """复制DynamicFormFiller中的_generate_option_variants方法"""
        variants = []
        value_lower = value.lower().strip()
        
        # 1. 原始值
        variants.append(value)
        
        # 2. 大小写变体
        variants.extend([value.upper(), value.lower(), value.capitalize()])
        
        # 3. Yes/No 类型的特殊处理
        if value_lower in ['yes', 'true', '是', 'y']:
            variants.extend([
                'Yes', 'YES', 'yes',
                'Yes (是)', 'YES (是)', 'yes (是)',
                '是', 'True', 'true', 'TRUE'
            ])
        elif value_lower in ['no', 'false', '否', 'n']:
            variants.extend([
                'No', 'NO', 'no',
                'No (否)', 'NO (否)', 'no (否)',
                '否', 'False', 'false', 'FALSE'
            ])
        
        # 4. 常见的中英文混合格式
        mixed_format_mappings = {
            'adult': ['Adult', 'Adult (成人)', 'ADULT (成人)', 'adult (成人)', '成人'],
            'child': ['Child', 'Child (儿童)', 'CHILD (儿童)', 'child (儿童)', '儿童'],
            'teen': ['Teen', 'Teen (青少年)', 'TEEN (青少年)', 'teen (青少年)', '青少年'],
            'new': ['New', 'New (全新)', 'NEW (全新)', 'new (全新)', '全新'],
            'used': ['Used', 'Used (二手)', 'USED (二手)', 'used (二手)', '二手'],
            'indoor': ['Indoor', 'Indoor (室内)', 'INDOOR (室内)', 'indoor (室内)', '室内'],
            'outdoor': ['Outdoor', 'Outdoor (室外)', 'OUTDOOR (室外)', 'outdoor (室外)', '室外']
        }
        
        for key, value_variants in mixed_format_mappings.items():
            if key in value_lower:
                variants.extend(value_variants)
        
        # 5. 数字相关的特殊处理
        if value.isdigit():
            # 为数字添加可能的中文说明
            number_mappings = {
                '0': ['0', '0 - No warning applicable', '0 - 无警告适用'],
                '1': ['1', '1 Each', '1 (每个)', 'Each (每个)']
            }
            if value in number_mappings:
                variants.extend(number_mappings[value])
        
        # 6. 单位相关的变体
        unit_mappings = {
            'inches': ['inches', 'in', 'in (英寸)', '英寸'],
            'feet': ['feet', 'ft', 'ft (英尺)', '英尺'],
            'pounds': ['pounds', 'lbs', 'lb', 'lb (磅)', 'lbs (磅)', '磅'],
            'each': ['each', 'Each', 'Each (每个)', '每个']
        }
        
        for unit, unit_variants in unit_mappings.items():
            if unit in value_lower:
                variants.extend(unit_variants)
        
        # 7. 移除重复项并保持顺序
        unique_variants = []
        seen = set()
        for variant in variants:
            if variant and variant not in seen:
                unique_variants.append(variant)
                seen.add(variant)
        
        return unique_variants

def test_option_variants_generation():
    """测试选项变体生成"""
    print("🧪 测试选项变体生成...")
    
    mock_filler = MockFormFiller()
    
    test_cases = [
        {
            'input': 'No',
            'description': '英文No转中英文混合',
            'expected_contains': ['No (否)', 'NO (否)', 'no (否)', '否']
        },
        {
            'input': 'Yes', 
            'description': '英文Yes转中英文混合',
            'expected_contains': ['Yes (是)', 'YES (是)', 'yes (是)', '是']
        },
        {
            'input': 'Adult',
            'description': '成人年龄组',
            'expected_contains': ['Adult (成人)', 'ADULT (成人)', 'adult (成人)', '成人']
        },
        {
            'input': 'New',
            'description': '新品条件',
            'expected_contains': ['New (全新)', 'NEW (全新)', 'new (全新)', '全新']
        },
        {
            'input': '0',
            'description': '数字0的警告代码',
            'expected_contains': ['0 - No warning applicable', '0 - 无警告适用']
        },
        {
            'input': '1',
            'description': '数字1的数量单位',
            'expected_contains': ['1 Each', '1 (每个)', 'Each (每个)']
        }
    ]
    
    print(f"\n🔍 开始测试 {len(test_cases)} 种变体生成场景:")
    
    for i, test_case in enumerate(test_cases, 1):
        input_value = test_case['input']
        description = test_case['description']
        expected_contains = test_case['expected_contains']
        
        print(f"\n📋 测试 {i}: {description}")
        print(f"   输入: '{input_value}'")
        
        variants = mock_filler._generate_option_variants(input_value)
        print(f"   生成 {len(variants)} 个变体:")
        
        for j, variant in enumerate(variants[:10], 1):  # 显示前10个变体
            print(f"     {j}: '{variant}'")
        
        if len(variants) > 10:
            print(f"     ... (+{len(variants)-10} 更多变体)")
        
        # 验证期望的变体是否存在
        found_expected = []
        for expected in expected_contains:
            if expected in variants:
                found_expected.append(expected)
        
        status = "✅" if len(found_expected) == len(expected_contains) else "⚠️"
        print(f"   {status} 找到期望变体 {len(found_expected)}/{len(expected_contains)}: {found_expected}")

def test_fuzzy_matching_logic():
    """测试模糊匹配逻辑"""
    print(f"\n🧪 测试模糊匹配逻辑...")
    
    # 模拟的选项匹配测试
    fuzzy_test_cases = [
        {
            'input_value': 'No',
            'available_options': ['Yes (是)', 'No (否)', 'Maybe'],
            'expected_match': 'No (否)'
        },
        {
            'input_value': 'Adult',
            'available_options': ['Child (儿童)', 'Teen (青少年)', 'Adult (成人)', 'Senior'],
            'expected_match': 'Adult (成人)'
        },
        {
            'input_value': 'New',
            'available_options': ['Used (二手)', 'New (全新)', 'Refurbished'],
            'expected_match': 'New (全新)'
        },
        {
            'input_value': 'Indoor',
            'available_options': ['Outdoor (室外)', 'Indoor (室内)', 'Both'],
            'expected_match': 'Indoor (室内)'
        }
    ]
    
    print(f"🔍 测试 {len(fuzzy_test_cases)} 种模糊匹配场景:")
    
    for i, test_case in enumerate(fuzzy_test_cases, 1):
        input_value = test_case['input_value']
        available_options = test_case['available_options']
        expected_match = test_case['expected_match']
        
        print(f"\n📋 测试 {i}: 匹配 '{input_value}'")
        print(f"   可用选项: {available_options}")
        
        # 模拟模糊匹配逻辑
        value_lower = input_value.lower().strip()
        matched_option = None
        
        for option in available_options:
            option_lower = option.lower()
            
            # 检查是否部分匹配
            if (value_lower in option_lower or 
                option_lower.startswith(value_lower) or
                any(word in option_lower for word in value_lower.split() if len(word) > 2)):
                matched_option = option
                break
        
        status = "✅" if matched_option == expected_match else "❌"
        print(f"   {status} 匹配结果: '{matched_option}' (期望: '{expected_match}')")
        
        if matched_option != expected_match:
            print(f"      ⚠️ 匹配不符合期望")

def test_real_world_scenarios():
    """测试真实世界场景"""
    print(f"\n🧪 测试真实场景...")
    
    # 模拟实际遇到的问题场景
    real_scenarios = [
        {
            'field': 'Is Prop 65 Warning Required',
            'default_value': 'No',
            'page_options': ['Yes (是)', 'No (否)'],
            'description': 'Prop 65警告字段'
        },
        {
            'field': 'Age Group',
            'default_value': 'Adult', 
            'page_options': ['Child (儿童)', 'Teen (青少年)', 'Adult (成人)', 'Senior (老年)'],
            'description': '年龄组字段'
        },
        {
            'field': 'Condition',
            'default_value': 'New',
            'page_options': ['New (全新)', 'Used (二手)', 'Refurbished (翻新)'],
            'description': '产品条件字段'
        },
        {
            'field': 'Has Written Warranty',
            'default_value': 'No',
            'page_options': ['Yes - Warranty Text (是-保修文本)', 'Yes - Warranty URL (是-保修链接)', 'No (否)'],
            'description': '保修字段'
        }
    ]
    
    print(f"🎯 测试 {len(real_scenarios)} 个真实场景:")
    
    for i, scenario in enumerate(real_scenarios, 1):
        field = scenario['field']
        default_value = scenario['default_value']
        page_options = scenario['page_options']
        description = scenario['description']
        
        print(f"\n📋 场景 {i}: {description}")
        print(f"   字段: {field}")
        print(f"   默认值: '{default_value}'")
        print(f"   页面选项: {page_options}")
        
        # 模拟变体生成
        mock_filler = MockFormFiller()
        variants = mock_filler._generate_option_variants(default_value)
        
        # 查找匹配的选项
        matched_options = []
        for variant in variants:
            for option in page_options:
                if variant == option:
                    matched_options.append(option)
        
        if matched_options:
            print(f"   ✅ 找到匹配选项: {matched_options}")
            print(f"   📈 匹配成功率: {len(matched_options)}/{len(page_options)} 可选项可匹配")
        else:
            print(f"   ❌ 未找到精确匹配")
            
            # 尝试模糊匹配
            print(f"   🔍 尝试模糊匹配...")
            value_lower = default_value.lower()
            fuzzy_matches = []
            
            for option in page_options:
                option_lower = option.lower()
                if value_lower in option_lower:
                    fuzzy_matches.append(option)
            
            if fuzzy_matches:
                print(f"   ⚠️ 模糊匹配找到: {fuzzy_matches}")
            else:
                print(f"   ❌ 模糊匹配也未找到合适选项")

def main():
    """主测试函数"""
    print("🚀 选择框选项匹配修复测试")
    print("=" * 60)
    print("目标：验证中英文混合选项的匹配能力")
    
    test_option_variants_generation()
    test_fuzzy_matching_logic()
    test_real_world_scenarios()
    
    print("\n" + "=" * 60)
    print("🎉 测试完成！")
    
    print("\n💡 修复要点:")
    print("1. 🌍 生成中英文混合格式变体 (No → No (否))")
    print("2. 🔤 支持大小写变体 (Adult → ADULT, adult)")
    print("3. 🔢 数字选项特殊处理 (0 → 0 - No warning applicable)")
    print("4. 🎯 智能模糊匹配作为后备策略")
    print("5. 📝 详细的匹配过程日志")
    print("6. 📋 更新默认值配置使用正确格式")
    
    print("\n🎯 预期修复效果:")
    print("- 'No' 能匹配 'No (否)'")
    print("- 'Adult' 能匹配 'Adult (成人)'") 
    print("- '0' 能匹配 '0 - No warning applicable'")
    print("- 大幅减少选择框填充失败")

if __name__ == "__main__":
    main()
