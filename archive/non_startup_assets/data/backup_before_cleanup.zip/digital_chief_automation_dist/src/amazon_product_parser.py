"""
Amazon Product Parser - 亚马逊产品信息解析工具类

重构后的统一Amazon产品解析器。
合并了main.py和main-table-model.py中的重复解析逻辑。

作者: Linus Torvalds (风格)
设计原则: Single Source of Truth, Good Taste, No Duplication
"""

import re
from typing import Dict, List, Optional, Any
from playwright.sync_api import Page
from product_data import ProductData


# ProductData 现在从 product_data.py 导入，不再重复定义


class AmazonProductParser:
    """
    亚马逊产品解析器
    
    单一职责：只负责从亚马逊页面提取产品信息
    Good Taste：每个方法只做一件事，数据结构简单清晰
    """
    
    def __init__(self, page: Page):
        self.page = page
        self.product_data = ProductData()
        
        # 解析器配置 - 所有的选择器和关键词都在这里，便于维护
        self.selectors = {
            'title': '#productTitle',
            'product_table_top': "table[class='a-normal a-spacing-micro']",
            'product_table_bottom': "table[class='a-keyvalue prodDetTable']",
            'glance_icons': '#glance_icons_div',
            'feature_bullets': '#feature-bullets ul.a-unordered-list li span.a-list-item',
            'weight_cell': "td:has-text('Item Weight')"
        }
        
        # 智能提取关键词
        self.keywords = {
            'materials': ['bamboo', 'wood', 'metal', 'plastic', 'steel', 'aluminum', 'glass', 'fabric'],
            'styles': ['modern', 'boho', 'scandinavian', 'industrial', 'rustic', 'minimalist', 'contemporary'],
            'rooms': ['living room', 'bedroom', 'bathroom', 'office', 'kitchen', 'entryway'],
            'assembly_no_tools': ['no hardware', 'tool-free', 'no screws', 'snap together'],
            'assembly_required': ['assembly', 'install', 'assemble']
        }
    
    def parse_product(self) -> ProductData:
        """
        解析产品信息的主入口
        
        这是唯一的public方法 - 简单明了
        """
        print("🔍 开始解析亚马逊产品信息...")
        
        try:
            # 确保页面完全加载
            self._prepare_page()
            
            # 按顺序解析各个部分
            self._parse_title()
            self._parse_weight()
            self._parse_colors()
            self._parse_item_package_quantity()
            self._parse_product_details_tables()
            self._parse_glance_icons()
            self._parse_feature_bullets()
            
            self.product_data.parse_success = True
            print(f"✅ 产品解析完成，共提取 {len(self.product_data.details)} 个属性")
            
        except Exception as e:
            error_msg = f"产品解析失败: {e}"
            print(f"❌ {error_msg}")
            self.product_data.parse_errors.append(error_msg)
        
        return self.product_data
    
    def _prepare_page(self) -> None:
        """准备页面 - 滚动确保内容加载"""
        try:
            print("🔍 开始Amazon产品页面解析...")
            # 持续监测并点击反爬虫拦截按钮，直到按钮消失
            while True:
                continue_button = self.page.locator("button.a-button-text[alt='Continue shopping']")
                if continue_button.count() > 0 and continue_button.is_visible():
                    print("⚠️ 检测到反爬虫拦截，尝试点击Continue按钮...")
                    try:
                        self.page.wait_for_timeout(2000)
                        # 点击Continue按钮
                        continue_button.click()
                        # 等待页面重新加载
                        self.page.wait_for_load_state("domcontentloaded")
                        print("✅ 点击Continue按钮成功，页面已重新加载")
                        # 等待一段时间以确保页面稳定
                        self.page.wait_for_timeout(1000)
                    except Exception as e:
                        print(f"⚠️ 点击Continue按钮失败: {e}")
                else:
                    print("✅ 反爬虫拦截按钮已消失，继续解析流程")
                    break
            print("检查配送地址是否为纽约10001")
            deliver_to = self.page.locator("#glow-ingress-line2").inner_text()
            print(f"deliver_to: {deliver_to}")
            if not deliver_to.__contains__("10001"):
                print("配送地点不是纽约10001，准备切换")
                language_button = self.page.locator("#nav-global-location-popover-link")
                language_button.wait_for(timeout=2000)
                print("切换语言和地区设置")
                language_button.click()
            
                # Wait for the location dialog to appear
                self.page.wait_for_selector("#GLUXZipUpdateInput", timeout=10000)
                
                # Fill the zip code
                zip_input = self.page.locator("#GLUXZipUpdateInput")
                zip_input.fill("10001")
                print("已填写邮政编码: 10001")
                
                # Click the Apply button
                apply_button = self.page.locator("#GLUXZipUpdate")
                apply_button.click()
                print("已点击应用按钮")
                input("切换成功后回车键继续...")
        
            self.page.wait_for_load_state("domcontentloaded")
      
            # 滚动到页面底部，然后回到顶部，确保所有内容加载
            print("滚动页面到底部显示所有元素...")
            self.page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            self.page.wait_for_timeout(2000)
            self.page.wait_for_load_state("load")
            
            # 滚动回到顶部
            self.page.evaluate("window.scrollTo(0, 0)")
            self.page.wait_for_timeout(2000)
            
            # 再次滚动到中间位置，确保产品详情区域可见
            self.page.evaluate("window.scrollTo(0, document.body.scrollHeight * 0.5)")
            self.page.wait_for_timeout(1000)
            
            print("页面滚动完成，准备开始解析...")
           
        except Exception as e:
            print(f"⚠️ 页面准备过程中出现警告: {e}")
    
    def _parse_title(self) -> None:
        """解析产品标题"""
        try:
            title_element = self.page.locator(self.selectors['title']).first
            self.product_data.asin = self.page.url.split('/dp/')[1].split('?')[0].replace('/','')
            self.product_data.title = title_element.inner_text()
            price_str = self.page.locator("div[data-feature-name='corePrice'] span.a-offscreen").first.inner_text()
            self.product_data.price = float(price_str.replace('$', ''))
            delivery_price_str = self.page.locator("span[data-csa-c-delivery-type='delivery']").first.get_attribute('data-csa-c-delivery-price')
            self.product_data.delivery_price = 0;
            if delivery_price_str!='FREE':
                self.product_data.delivery_price=float((delivery_price_str or '0').replace('$', ''))
            print(f"📝 产品标题: {self.product_data.title[:50]}...")
            print(f"💰 产品价格: ${self.product_data.price:.2f}")
            print(f"🚚 运费价格: ${self.product_data.delivery_price:.2f}")
            self.product_data.add_detail('Title', self.product_data.title)
            self.product_data.add_detail('ASIN', self.product_data.asin)
            self.product_data.add_detail('Price', f"{self.product_data.price}")
            self.product_data.add_detail('Delivery Price', f"{self.product_data.delivery_price}")   
        except Exception as e:
            self._add_error(f"标题解析失败: {e}")
    
    def _parse_colors(self) -> None:
        """
        解析产品颜色 - 从Amazon产品变体选择器中获取颜色信息
        
        Good Taste: 多策略提取颜色信息，优先获取当前选中的颜色，同时收集所有可用颜色选项
        """
        try:
            # 策略1: 获取当前选中的颜色（从展开的维度文本中）
            selected_color = self._get_selected_color()
            
            # 策略2: 获取所有可用的颜色选项
            available_colors: List[str] = self._get_available_colors()
            
            # 设置颜色信息
            if selected_color:
                self.product_data.add_detail('Selected Color', str(selected_color))
                print(f"✅ 当前选中颜色: {selected_color}")
            
            if available_colors:
                self.product_data.add_detail('Available Colors', ', '.join(available_colors))
                print(f"✅ 可用颜色选项: {', '.join(available_colors)}")
            
            # # 如果没有找到任何颜色信息，尝试从产品详情中获取
            # if not selected_color and not available_colors:
            #     self._get_color_from_details()
                
        except Exception as e:
            print(f"⚠️ 颜色解析失败: {e}")
            # 设置默认值
            if 'Color' not in self.product_data.details:
                self.product_data.add_detail('Color', 'Not specified')
    
    def _get_selected_color(self) -> Optional[object]:
        """获取当前选中的颜色"""
        try:
            # 多种选择器策略获取选中的颜色
            selectors = [
                # 策略1: 从展开的维度文本中获取
                "#inline-twister-expanded-dimension-text-color_name",
                # 策略2: 从颜色标题区域获取
                ".inline-twister-dim-title-value",
                # 策略3: 从选中的按钮获取
                ".a-button-selected img[alt*='pack']",
                # 策略4: 更通用的选中颜色选择器
                "[id*='color_name'][class*='selected'] img"
            ]
            
            for selector in selectors:
                try:
                    element = self.page.locator(selector).first
                    if element.count() > 0:
                        if 'img' in selector:
                            # 从图片的alt属性获取颜色
                            alt_text = element.get_attribute('alt')
                            color_text = alt_text
                        else:
                            # 从文本内容获取颜色
                            color_text = element.inner_text().strip()
                        
                        if color_text:
                            return color_text
                            # # 清理和标准化颜色文本
                            # cleaned_color = self._clean_color_text(color_text)
                            # if cleaned_color:
                            #     print(f"  ✅ 使用选择器 {selector[:30]}... 获取到颜色: {cleaned_color}")
                            #     return cleaned_color
                except Exception as e:
                    print(f"  选择器 {selector[:30]}... 失败: {e}")
                    continue
            
            return None
            
        except Exception as e:
            print(f"获取选中颜色失败: {e}")
            return None
    
    def _get_available_colors(self) -> List[str]:
        """获取所有可用的颜色选项"""
        colors = []
        try:
            # 查找所有颜色选项的图片元素
            color_images = self.page.locator("#inline-twister-row-color_name img.swatch-image")
            count = color_images.count()
            
            print(f"  🎨 找到 {count} 个颜色选项")
            
            for i in range(count):
                try:
                    img = color_images.nth(i)
                    alt_text = img.get_attribute('alt')
                    
                    if alt_text:
                        colors.append(alt_text)
                        # cleaned_color = self._clean_color_text(alt_text)
                        # if cleaned_color and cleaned_color not in colors:
                        #     colors.append(cleaned_color)
                        #     print(f"    ✅ 颜色选项 {i+1}: {cleaned_color}")
                            
                except Exception as e:
                    print(f"    ❌ 颜色选项 {i+1} 处理失败: {e}")
                    continue
            
            return colors
            
        except Exception as e:
            print(f"获取可用颜色失败: {e}")
            return []
    
    def _clean_color_text(self, color_text: str) -> Optional[str]:
        """清理和标准化颜色文本"""
        if not color_text:
            return None
        
        # 移除常见的前缀和后缀
        cleaned = color_text.strip()
        
        # 移除包装数量信息（如 "1-pack", "2-pack"）
        import re
        cleaned = re.sub(r'^\d+-pack\s+', '', cleaned, flags=re.IGNORECASE)
        
        # 移除其他常见前缀
        prefixes_to_remove = ['color:', 'colour:', 'selected color is']
        for prefix in prefixes_to_remove:
            if cleaned.lower().startswith(prefix):
                cleaned = cleaned[len(prefix):].strip()
        
        # 移除末尾的标点符号
        cleaned = re.sub(r'[.。]+$', '', cleaned)
        
        # 如果清理后为空或太短，返回None
        if len(cleaned.strip()) < 2:
            return None
            
        return cleaned.strip()
    
    def _get_color_from_details(self) -> None:
        """从产品详情中获取颜色信息（备用方案）"""
        try:
            # 检查是否已经从产品详情表格中获取了颜色信息
            color_keys = ['Color', 'Colour', 'Item Color', 'Product Color']
            
            for key in color_keys:
                if key in self.product_data.details:
                    color_value = self.product_data.details[key]
                    print(f"  ✅ 从产品详情获取颜色: {color_value}")
                    return
            
            # 如果没有找到，设置默认值
            self.product_data.add_detail('Color', 'Not specified')
            print("  ⚠️ 未找到颜色信息，使用默认值")
            
        except Exception as e:
            print(f"从产品详情获取颜色失败: {e}")
    
    def _parse_item_package_quantity(self) -> None:
        """
        解析产品包装数量 - 从Amazon产品变体选择器中获取包装数量信息
        
        Good Taste: 多策略提取包装数量信息，优先获取当前选中的数量，同时收集所有可用选项
        """
        try:
            # 策略1: 获取当前选中的包装数量（从展开的维度文本中）
            selected_quantity = self._get_selected_package_quantity()
            
            # 策略2: 获取所有可用的包装数量选项
            available_quantities = self._get_available_package_quantities()
            
            # 设置包装数量信息
            if selected_quantity:
                self.product_data.add_detail('Selected Package Quantity', str(selected_quantity))
                print(f"✅ 当前选中包装数量: {selected_quantity}")
            
            if available_quantities:
                quantities_str = ', '.join(map(str, available_quantities))
                self.product_data.add_detail('Available Package Quantities', quantities_str)
                print(f"✅ 可用包装数量选项: {quantities_str}")
            
            # # 如果没有找到任何包装数量信息，尝试从产品详情中获取
            # if not selected_quantity and not available_quantities:
            #     self._get_package_quantity_from_details()
                
        except Exception as e:
            print(f"⚠️ 包装数量解析失败: {e}")
            # 设置默认值
            if 'Package Quantity' not in self.product_data.details:
                self.product_data.add_detail('Package Quantity', '1')
    
    def _get_selected_package_quantity(self) -> Optional[str]:
        """获取当前选中的包装数量"""
        try:
            # 多种选择器策略获取选中的包装数量
            selectors = [
                # 策略1: 从展开的维度文本中获取
                "#inline-twister-expanded-dimension-text-item_package_quantity",
                # 策略2: 从包装数量标题区域获取
                "#inline-twister-dim-title-item_package_quantity .inline-twister-dim-title-value",
                # 策略3: 从选中的按钮获取
                ".a-button-selected .swatch-title-text-display",
                # 策略4: 更通用的选中数量选择器
                "[id*='item_package_quantity'][class*='selected'] .swatch-title-text"
            ]
            
            for selector in selectors:
                try:
                    element = self.page.locator(selector).first
                    if element.count() > 0:
                        quantity_text = element.inner_text().strip()
                        
                        if quantity_text:
                            # 清理和标准化数量文本
                            cleaned_quantity = self._clean_quantity_text(quantity_text)
                            if cleaned_quantity:
                                print(f"  ✅ 使用选择器 {selector[:40]}... 获取到数量: {cleaned_quantity}")
                                return cleaned_quantity
                except Exception as e:
                    print(f"  选择器 {selector[:40]}... 失败: {e}")
                    continue
            
            return None
            
        except Exception as e:
            print(f"获取选中包装数量失败: {e}")
            return None
    
    def _get_available_package_quantities(self) -> List[str]:
        """获取所有可用的包装数量选项"""
        quantities = []
        try:
            # 查找所有包装数量选项的文本元素
            quantity_elements = self.page.locator("#inline-twister-row-item_package_quantity .swatch-title-text-display")
            count = quantity_elements.count()
            
            print(f"  📦 找到 {count} 个包装数量选项")
            
            for i in range(count):
                try:
                    element = quantity_elements.nth(i)
                    quantity_text = element.inner_text().strip()
                    
                    if quantity_text:
                        cleaned_quantity = self._clean_quantity_text(quantity_text)
                        if cleaned_quantity and cleaned_quantity not in quantities:
                            quantities.append(cleaned_quantity)
                            print(f"    ✅ 数量选项 {i+1}: {cleaned_quantity}")
                            
                except Exception as e:
                    print(f"    ❌ 数量选项 {i+1} 处理失败: {e}")
                    continue
            
            return quantities
            
        except Exception as e:
            print(f"获取可用包装数量失败: {e}")
            return []
    
    def _clean_quantity_text(self, quantity_text: str) -> Optional[str]:
        """清理和标准化数量文本"""
        if not quantity_text:
            return None
        
        # 移除常见的前缀和后缀
        cleaned = quantity_text.strip()
        
        # 移除常见前缀
        import re
        prefixes_to_remove = ['item package quantity:', 'package quantity:', 'quantity:']
        for prefix in prefixes_to_remove:
            if cleaned.lower().startswith(prefix):
                cleaned = cleaned[len(prefix):].strip()
        
        # 提取数字
        number_match = re.search(r'(\d+)', cleaned)
        if number_match:
            return number_match.group(1)
        
        # 如果没有数字，返回原文本（去除空格）
        if len(cleaned.strip()) >= 1:
            return cleaned.strip()
            
        return None
    
    def _get_package_quantity_from_details(self) -> None:
        """从产品详情中获取包装数量信息（备用方案）"""
        try:
            # 检查是否已经从产品详情表格中获取了包装数量信息
            quantity_keys = ['Package Quantity', 'Item Package Quantity', 'Quantity', 'Pack Size']
            
            for key in quantity_keys:
                if key in self.product_data.details:
                    quantity_value = self.product_data.details[key]
                    print(f"  ✅ 从产品详情获取包装数量: {quantity_value}")
                    return
            
            # 如果没有找到，设置默认值
            self.product_data.add_detail('Package Quantity', '1')
            print("  ⚠️ 未找到包装数量信息，使用默认值: 1")
            
        except Exception as e:
            print(f"从产品详情获取包装数量失败: {e}")
        
    def _parse_weight(self) -> None:
        """
        解析产品重量 - 合并main.py中的增强鲁棒策略
        
        Good Taste: 简单的回退机制，不过度设计
        """
        weight_value = '10'  # 默认值
        
        # 策略1: 从已提取的detail_pairs中查找重量
        if 'Item Weight' in self.product_data.details:
            try:
                weight_str = self.product_data.details['Item Weight']
                weight_match = re.search(r'([0-9.]+)', weight_str)
                if weight_match:
                    weight_value = weight_match.group(1)
                    print(f"✅ 从产品详情获取重量: {weight_value} (原值: {weight_str})")
            except Exception as e:
                print(f"解析产品详情重量失败: {e}")
        
        # 策略2: 尝试直接定位重量元素（如果上面没有找到）
        if weight_value == '10':  # 还是默认值，说明上面没找到
            weight_selectors = [
                # 策略2a: 原始选择器
                "td:has-text('Item Weight') span.a-size-base.handle-overflow",
                # 策略2b: 简化选择器
                "td:has-text('Item Weight') span",
                # 策略2c: 更宽泛的选择器
                "td:has-text('Item Weight')",
                # 策略2d: 包含weight的所有元素
                "[data-feature-name*='weight'], [id*='weight'], .weight-info",
                # 策略2e: 产品详情表格中的重量
                "#productDetails_detailBullets_sections1 span:has-text('pounds'), #productDetails_detailBullets_sections1 span:has-text('lbs')"
            ]
            
            for i, selector in enumerate(weight_selectors, 1):
                try:
                    print(f"🔍 尝试策略 {i}: {selector[:50]}...")
                    # 使用较短的超时时间
                    self.page.wait_for_selector(selector.split()[0], timeout=3000)
                    
                    elements = self.page.locator(selector)
                    count = elements.count()
                    print(f"   找到 {count} 个匹配元素")
                    
                    for j in range(count):
                        try:
                            element_text = elements.nth(j).inner_text(timeout=5000)
                            print(f"   元素 {j+1} 文本: {element_text[:50]}...")
                            
                            # 提取数字
                            weight_match = re.search(r'([0-9.]+)\s*(?:pounds?|lbs?)', element_text, re.IGNORECASE)
                            if weight_match:
                                weight_value = weight_match.group(1)
                                print(f"✅ 使用策略 {i} 获取重量: {weight_value}")
                                break
                            
                            # 如果没有单位，尝试提取任意数字
                            number_match = re.search(r'([0-9.]+)', element_text)
                            if number_match and selector == weight_selectors[0]:  # 只在精确选择器下使用
                                weight_value = number_match.group(1)
                                print(f"✅ 使用策略 {i} 获取数字: {weight_value}")
                                break
                                
                        except Exception as element_error:
                            print(f"   元素 {j+1} 处理失败: {element_error}")
                            continue
                    
                    if weight_value != '10':  # 找到了
                        break
                        
                except Exception as selector_error:
                    print(f"   策略 {i} 失败: {selector_error}")
                    continue
        
        # 设置最终重量值
        self.product_data.weight_value = weight_value
        if 'Item Weight' not in self.product_data.details:
            self.product_data.add_detail('Item Weight', f"{weight_value} pounds")
        
        print(f"🎩 最终重量值: {weight_value}")
    
    def _parse_product_details_tables(self) -> None:
        """解析产品详情表格"""
        # 解析顶部表格
        self._parse_table(self.selectors['product_table_top'], "顶部产品详情")
        
        # 解析底部表格们 - 先展开可扩展区域，再解析表格
        try:
            # 首先尝试展开所有可扩展的产品详情区域
            self._expand_product_details_sections()
            
            # 等待一下让展开动画完成
            self.page.wait_for_timeout(1000)
            
            # 检查元素是否存在
            print("🔍 检查底部表格存在性...")
            bottom_tables = self.page.locator(self.selectors['product_table_bottom'])
            count = bottom_tables.count()
            print(f"📊 找到底部表格数量: {count}")
            
            if count == 0:
                print("⚠️ 未找到任何底部表格，跳过")
                return
            
            # 智能处理：检查每个表格的可见性
            visible_count = 0
            for i in range(count):
                try:
                    table = bottom_tables.nth(i)
                    
                    # 检查这个表格是否可见
                    try:
                        # 短时间等待这个特定表格变为可见
                        table.wait_for(state="visible", timeout=3000)
                        visible_count += 1
                        print(f"✅ 表格 {i+1} 已可见，开始解析...")
                        
                        # 使用结构化方法解析这个表格
                        self._parse_single_table_structured(table, f"底部表格 {i+1}")
                        
                    except Exception as visibility_error:
                        print(f"⚠️ 表格 {i+1} 不可见或等待超时，跳过: {visibility_error}")
                        continue
                        
                except Exception as table_error:
                    print(f"⚠️ 第 {i+1} 个底部表格处理失败: {table_error}")
                    continue
            
            print(f"📋 底部表格解析完成，{visible_count}/{count} 个表格成功处理")
                    
        except Exception as e:
            print(f"⚠️ 底部产品详情获取失败: {e}")
    
    def _parse_table(self, selector: str, table_name: str) -> None:
        """解析单个表格"""
        try:
            self.page.wait_for_selector(selector, state="attached", timeout=5000)
            table_text = self.page.locator(selector).inner_text()
            self._parse_table_text(table_text)
            print(f"✅ {table_name} 解析完成")
        except Exception as e:
            print(f"⚠️ {table_name} 解析失败: {e}")
    
    def _parse_table_text(self, table_text: str) -> None:
        """解析表格文本内容"""
        lines = table_text.strip().split('\n')
        for line in lines:
            if '\t' in line:
                key, value = line.split('\t', 1)
                self.product_data.add_detail(key, value)
    
    def _expand_product_details_sections(self) -> None:
        """展开所有产品详情可扩展区域"""
        try:
            print("🔍 查找并展开产品详情区域...")
            
            # 查找所有可扩展的产品详情区域
            expander_selectors = [
                # 主要的产品详情展开器
                "a.a-expander-header[data-action='a-expander-toggle']",
                # 带有 Item details 文本的展开器
                "a.a-expander-header:has-text('Item details')",
                # 产品详情区域的展开器
                ".a-expander-container .a-expander-header",
                # 更通用的展开器选择器
                "[data-action='a-expander-toggle']"
            ]
            
            expanded_count = 0
            for selector in expander_selectors:
                try:
                    expanders = self.page.locator(selector)
                    count = expanders.count()
                    
                    if count > 0:
                        print(f"  找到 {count} 个展开器 (选择器: {selector[:40]}...)")
                        
                        for i in range(count):
                            try:
                                expander = expanders.nth(i)
                                
                                # 检查是否已经展开
                                aria_expanded = expander.get_attribute("aria-expanded")
                                if aria_expanded == "true":
                                    print(f"    展开器 {i+1} 已经展开，跳过")
                                    continue
                                
                                # 尝试点击展开
                                if expander.is_visible():
                                    expander.click()
                                    expanded_count += 1
                                    print(f"    ✅ 展开器 {i+1} 点击成功")
                                    
                                    # 短暂等待展开动画
                                    self.page.wait_for_timeout(500)
                                else:
                                    print(f"    展开器 {i+1} 不可见，跳过")
                                    
                            except Exception as e:
                                print(f"    ❌ 展开器 {i+1} 点击失败: {e}")
                                continue
                except Exception as e:
                    print(f"  选择器 {selector[:40]}... 处理失败: {e}")
                    continue
            
            print(f"✅ 成功展开 {expanded_count} 个产品详情区域")
            
        except Exception as e:
            print(f"⚠️ 展开产品详情区域失败: {e}")
    
    def _parse_single_table_structured(self, table_element, table_name: str) -> None:
        """解析单个结构化表格 (th/td格式)"""
        try:
            # 查找所有的tr元素
            tr_elements = table_element.locator("tr")
            
            parsed_count = 0
            for i in range(tr_elements.count()):
                try:
                    tr = tr_elements.nth(i)
                    # 查找th和td元素
                    th_elements = tr.locator("th")
                    td_elements = tr.locator("td")
                    
                    # 确保有一个th和一个td
                    if th_elements.count() >= 1 and td_elements.count() >= 1:
                        key = th_elements.first.inner_text().strip()
                        # 对于td中的复杂内容，我们只取文本部分
                        value = td_elements.first.inner_text().strip()
                        
                        # 过滤掉空值
                        if key and value:
                            # 清理值中的多余空白字符
                            value = re.sub(r'\s+', ' ', value).strip()
                            self.product_data.add_detail(key, value)
                            parsed_count += 1
                            print(f"  ✅ {key}: {value[:50]}{'...' if len(value) > 50 else ''}")
                except Exception as e:
                    print(f"  ❌ 表格行 {i+1} 解析失败: {e}")
            
            print(f"✅ {table_name} 结构化解析完成，共提取 {parsed_count} 个属性")
        except Exception as e:
            print(f"⚠️ {table_name} 结构化解析失败: {e}")

    def _parse_glance_icons(self) -> None:
        """解析产品特征区域 (glance_icons_div)"""
        try:
            self.page.wait_for_selector(self.selectors['glance_icons'], timeout=1000)
            glance_icons = self.page.locator(self.selectors['glance_icons'])
            bold_elements = glance_icons.locator("span.a-text-bold")
            
            extracted_count = 0
            for i in range(bold_elements.count()):
                try:
                    # 获取标题
                    title_element = bold_elements.nth(i)
                    title = title_element.inner_text().strip()
                    
                    # 获取值
                    parent_td = title_element.locator("xpath=ancestor::td[1]")
                    value_spans = parent_td.locator("span.handle-overflow:not(.a-text-bold)")
                    
                    if value_spans.count() > 0:
                        value = value_spans.first.inner_text().strip()
                        self.product_data.add_detail(title, value)
                        extracted_count += 1
                        print(f"  ✅ {title}: {value}")
                
                except Exception as e:
                    print(f"  ❌ 第{i+1}个特征提取失败: {e}")
            
            print(f"✅ 从产品特征区域提取了 {extracted_count} 个属性")
            
        except Exception as e:
            print(f"⚠️ 产品特征区域解析失败: {e}")
    
    def _parse_feature_bullets(self) -> None:
        """解析产品功能描述区域"""
        try:
            self.page.wait_for_selector("#feature-bullets", timeout=3000)
            feature_bullets = self.page.locator(self.selectors['feature_bullets'])
            
            # 提取所有功能特点
            feature_descriptions = []
            for i in range(feature_bullets.count()):
                try:
                    feature_text = feature_bullets.nth(i).inner_text().strip()
                    if feature_text and len(feature_text) > 10:  # 过滤太短的文本
                        feature_descriptions.append(feature_text)
                        print(f"  ✅ 功能特点 {i+1}: {feature_text[:60]}...")
                except Exception as e:
                    print(f"  ❌ 第{i+1}个功能特点提取失败: {e}")
            
            if feature_descriptions:
                # 处理功能描述
                self._process_feature_descriptions(feature_descriptions)
                print(f"✅ 从功能描述提取了 {len(feature_descriptions)} 个特点")
            else:
                print("⚠️ 未找到任何功能特点")
                
        except Exception as e:
            print(f"⚠️ 产品功能描述解析失败: {e}")
    
    def _process_feature_descriptions(self, feature_descriptions: List[str]) -> None:
        """处理功能描述，提取关键信息"""
        # 合并所有功能特点
        combined_features = " | ".join(feature_descriptions)
        # self.product_data.add_detail('Feature Description', combined_features)
        self.product_data.add_detail('Key Features', combined_features)
        
        features_text = combined_features.lower()
        
        # 智能提取各种属性
        self._extract_material(features_text)
        self._extract_weight_capacity(features_text)
        self._extract_assembly_info(features_text)
        self._extract_style(features_text)
        self._extract_room_type(features_text)
    
    def _extract_material(self, text: str) -> None:
        """提取材质信息"""
        for material in self.keywords['materials']:
            if material in text and 'Material' not in self.product_data.details:
                self.product_data.add_detail('Material', material.capitalize())
                print(f"  ✨ 智能提取材质: {material.capitalize()}")
                break
    
    def _extract_weight_capacity(self, text: str) -> None:
        """提取承重信息"""
        weight_pattern = r'(\d+)\s*(?:lb|lbs|pound|pounds)'
        weight_matches = re.findall(weight_pattern, text)
        if weight_matches and 'Max Weight Capacity' not in self.product_data.details:
            max_weight = max([int(w) for w in weight_matches])
            self.product_data.add_detail('Max Weight Capacity', f"{max_weight} lbs")
            print(f"  ✨ 智能提取承重: {max_weight} lbs")
    
    def _extract_assembly_info(self, text: str) -> None:
        """提取组装信息"""
        if any(keyword in text for keyword in self.keywords['assembly_no_tools']):
            self.product_data.add_detail('Assembly Required', 'No')
            self.product_data.add_detail('Assembly Type', 'Tool-Free')
            print("  ✨ 智能提取组装信息: 无需工具")
        elif any(keyword in text for keyword in self.keywords['assembly_required']):
            self.product_data.add_detail('Assembly Required', 'Yes')
            print("  ✨ 智能提取组装信息: 需要组装")
    
    def _extract_style(self, text: str) -> None:
        """提取风格信息"""
        for style in self.keywords['styles']:
            if style in text and 'Style' not in self.product_data.details:
                self.product_data.add_detail('Style', style.capitalize())
                print(f"  ✨ 智能提取风格: {style.capitalize()}")
                break
    
    def _extract_room_type(self, text: str) -> None:
        """提取适用房间信息"""
        found_rooms = []
        for room in self.keywords['rooms']:
            if room in text:
                found_rooms.append(room.title())
        
        if found_rooms and 'Room Type' not in self.product_data.details:
            self.product_data.add_detail('Room Type', ', '.join(found_rooms))
            print(f"  ✨ 智能提取适用房间: {', '.join(found_rooms)}")
    
    def _add_error(self, error_msg: str) -> None:
        """添加错误信息"""
        self.product_data.parse_errors.append(error_msg)
        print(f"❌ {error_msg}")
    
    def print_summary(self) -> None:
        """打印解析结果摘要"""
        if not self.product_data.has_valid_data():
            print("❌ 未获取到任何产品数据")
            return
            
        print("\n" + "="*80)
        print("🎯 AMAZON 产品解析结果摘要")
        print("="*80)
        
        if self.product_data.title:
            print(f"📝 标题: {self.product_data.title}")
        
        if self.product_data.weight_value != '10':
            print(f"⚖️ 重量: {self.product_data.weight_value} pounds")
        
        print(f"📊 提取属性总数: {len(self.product_data.details)}")
        
        if self.product_data.details:
            print("\n📋 产品详情:")
            print("{:<30} {:<50}".format("属性", "值"))
            print("-" * 80)
            for key, value in self.product_data.details.items():
                # 限制输出长度
                display_value = str(value)[:47] + "..." if len(str(value)) > 50 else str(value)
                print("{:<30} {:<50}".format(str(key)[:27], display_value))
        
        if self.product_data.parse_errors:
            print(f"\n⚠️ 解析过程中的错误 ({len(self.product_data.parse_errors)} 个):")
            for error in self.product_data.parse_errors:
                print(f"  - {error}")
        
        print("="*80)
