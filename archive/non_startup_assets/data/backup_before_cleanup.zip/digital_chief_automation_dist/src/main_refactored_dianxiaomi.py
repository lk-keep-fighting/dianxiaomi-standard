#!/usr/bin/env python3
"""
重构后的主程序 - 统一的Amazon产品抓取和表单填充系统

重构成果：
1. 移除了重复的Amazon解析代码（163行 -> 0行）
2. 统一了映射系统（2套 -> 1套）
3. 合并了main.py和main-table-model.py的优势
4. Single Source of Truth架构

作者: Linus Torvalds (风格)
设计原则: Good Taste, No Duplication, Simple Data Flow
"""

import os
import re
import sys
import time
import datetime
from playwright.sync_api import Page, Playwright, sync_playwright

# 导入重构后的统一组件
from amazon_product_parser import AmazonProductParser
from product_data import ProductData
from unified_form_filler import UnifiedFormFiller


def check_script_expiration():
    """
    检查脚本有效期 - 保持原有的期限控制逻辑
    """
    timestamp_file = ".script_start_time"
    current_time = time.time()
    
    # 2小时有效期
    EXPIRATION_HOURS = 24*7
    EXPIRATION_SECONDS = EXPIRATION_HOURS * 60 * 60
    
    try:
        if os.path.exists(timestamp_file):
            # 读取开始时间
            with open(timestamp_file, 'r') as f:
                start_time = float(f.read().strip())
            
            # 检查是否超过期限
            elapsed_time = current_time - start_time
            remaining_time = EXPIRATION_SECONDS - elapsed_time
            
            if elapsed_time >= EXPIRATION_SECONDS:
                print("\n" + "="*50)
                print("⏰ 脚本使用期限已到期")
                print(f"📅 首次运行时间: {datetime.datetime.fromtimestamp(start_time).strftime('%Y-%m-%d %H:%M:%S')}")
                print(f"⌛ 使用期限: {EXPIRATION_HOURS} 小时")
                print(f"🚫 当前时间已超过使用期限")
                print("="*50)
                print("\n如需继续使用，请联系脚本提供者获取新版本。")
                sys.exit(1)
            else:
                # 显示剩余时间
                remaining_hours = remaining_time / 3600
                print(f"\n✅ 脚本仍在有效期内，剩余时间: {remaining_hours:.1f} 小时")
        else:
            # 首次运行 - 创建时间戳文件
            with open(timestamp_file, 'w') as f:
                f.write(str(current_time))
            print(f"\n🚀 脚本首次运行，使用期限: {EXPIRATION_HOURS} 小时")
            print(f"📅 开始时间: {datetime.datetime.fromtimestamp(current_time).strftime('%Y-%m-%d %H:%M:%S')}")
            
    except Exception as e:
        print(f"⚠️ 无法检查脚本有效期: {e}")
        # 出现错误时允许脚本运行但发出警告
        pass


def convert_weight_to_grams(weight_str: str) -> str:
    """
    将重量从磅转换为克，并移除单位
    
    Args:
        weight_str: 重量字符串，如 "39.68 Pounds" 或 "39.68"
        
    Returns:
        str: 转换后的克数，如 "17993"
    """
    import re
    
    try:
        if not weight_str:
            return "10"
        
        # 提取数字部分
        weight_match = re.search(r'([0-9.]+)', str(weight_str))
        if not weight_match:
            return "10"
        
        weight_pounds = float(weight_match.group(1))
        
        # 1磅 = 453.592克
        weight_grams = weight_pounds * 453.592
        
        # 返回整数克数
        return str(int(round(weight_grams)))
        
    except Exception as e:
        print(f"⚠️ 重量转换失败: {e}")
        return "10"


def extract_url_from_form(edit_frame):
    """
    从表单中提取Amazon产品URL
    
    Good Taste: 简单的URL提取逻辑，支持多种来源
    """
    url_sources = [
        {"type": "link", "selector": "a.linkUrl", "attr": "href"},
        {"type": "input", "selector": "input[name='productUrl']", "attr": "value"}
    ]
    
    web_url = ""
    for source in url_sources:
        try:
            elements = edit_frame.locator(source["selector"])
            if elements.count() > 0:
                element = elements.first
                # 先检查元素是否存在，不强制要求可见
                element.wait_for(state="attached", timeout=5000)
                # 尝试获取属性，即使元素不可见
                web_url = element.get_attribute(source["attr"])
                if web_url:
                    print(f"URL from {source['type']}: {web_url}")
                    break
        except Exception as e:
            print(f"Failed to get URL from {source['type']}: {e}")
    
    if not web_url or not web_url.startswith(('http://', 'https://')):
        print(f"Error: Invalid URL: {web_url}")
        return None
    
    return web_url
def get_edit_buttons(page: Page):
    """Locate all edit buttons in the product table"""
    # Wait for the table to load
    page.wait_for_selector(".vxe-table--body")
    
    # Find all edit buttons in the table
    # Based on the HTML structure, edit buttons are in the last column with text "编辑"
    edit_buttons = page.locator(".vxe-body--row .col_16 button:has-text('编辑')")
    
    # Wait for buttons to be visible
    edit_buttons.first.wait_for(state="visible")
    
    # Return the count and the locator
    count = edit_buttons.count()
    print(f"Found {count} edit buttons")
    return edit_buttons, count

def parse_amazon_product_enhanced(context, web_url):
    """
    使用增强的亚马逊产品解析器
    
    Returns:
        ProductData: 解析后的产品数据，如果失败返回None
    """
    if not web_url or not ('amazon.com' in web_url.lower() or 'amzn.to' in web_url.lower()):
        print(f"❌ 无效的亚马逊链接: {web_url}")
        return None
    
    # 打开新的亚马逊页面
    amazon_page = context.new_page()
    
    try:
        # 导航到亚马逊产品页面
        print(f"🌐 正在打开亚马逊产品页面: {web_url}")
        amazon_page.goto(web_url + '?language=en_US&currency=USD', timeout=60000)
        print("✅ 亚马逊页面加载完成")
        
    except Exception as e:
        print(f"❌ 导航到 {web_url} 失败: {e}")
        print("💡 请检查网络连接后重新执行")
        amazon_page.close()
        return None
    
    # 使用专业的产品解析器提取数据
    try:
        product_parser = AmazonProductParser(amazon_page)
        product_data = product_parser.parse_product()
        product_parser.print_summary()
        
        # 关闭亚马逊页面
        amazon_page.close()
        
        # 检查是否解析到有效数据
        if not product_data.has_valid_data():
            print("❌ 未获取到有效的产品数据")
            return None
            
        return product_data
        
    except Exception as e:
        print(f"❌ 产品解析器出错: {e}")
        amazon_page.close()
        return None

def show_product_preview_for_dianxiaomi(product_data: ProductData):
    """
    显示产品信息预览，供用户审核 - 针对店小秘平台优化
    
    Returns:
        bool: 用户是否确认继续填充表单
    """
    print("\n" + "="*80)
    print("📋 店小秘产品信息预览 - 请审核以下数据")
    print("="*80)
    print("\n" + "="*80)
    
    while True:
        choice = input("🤔 请选择操作 [Y]继续填充 / [N]跳过 / [D]查看详情: ").strip().upper()
        
        if choice in ['Y', 'YES', '']:
            print("✅ 用户确认，开始填充表单...")
            return True
        elif choice in ['N', 'NO']:
            print("⏭️ 用户跳过，不填充表单")
            return False
        elif choice in ['D', 'DETAIL', 'DETAILS']:
            # 显示完整详情
            print("\n" + "="*60)
            print("📋 完整产品详情")
            print("="*60)
            for key, value in product_data.to_dict().items():
                print(f"{key:<30}: {value}")
            print("="*60)
            continue
        else:
            print("❌ 无效选择，请输入 Y/N/D")


def fill_edit_form_enhanced(edit_page: Page, product_data: ProductData, manual_mode: bool = False) -> None:
    """
    增强版表单填充函数 - 针对店小秘平台优化
    
    Args:
        edit_page: 编辑页面对象
        product_data: 产品数据对象
        manual_mode: 是否为手动模式（影响填充策略）
    """
    try:
        # 转换产品数据为字典格式
        product_dict=   product_data.details
        print(f"🎯 开始填充店小秘表单（{'手动审核' if manual_mode else '自动'}模式）...")
        print(product_dict)
        try:
            asin_input = edit_page.locator("input[name='productItemNumber']")
            if asin_input.is_visible():
                asin_input.fill(product_dict["asin"])
                print(f"✅ 产品货号: {product_dict['asin']}")
        except Exception as e:
            print(f"⚠️ 货号填充失败: {e}")
        # Fill product model with "|" as specified
        try:
            edit_page.wait_for_selector("div.sheinDynamicAttr1000546 input.ant-input",timeout=1000)
            prod_model= edit_page.locator("div.sheinDynamicAttr1000546 input.ant-input")
            prod_model.fill("\\")
        except Exception as e:
            print(f"⚠️ 产品型号填充失败: {e}")
        try:
            selected_spec=''
            available_specs=[]  
            print("📦 规格信息: ")
            if("available package quantities" in product_dict):
                available_specs=product_dict["available package quantities"].split(",")
                selected_spec=product_dict["selected package quantity"]
                print(f"✅ 使用package规格信息: {selected_spec}")
            elif "available colors" in product_dict:
                available_specs=product_dict["available colors"].split(",")
                selected_spec=product_dict["selected color"]
                print(f"✅ 使用color规格信息: {selected_spec}")
            if available_specs.__len__() > 0:
                for spec in available_specs:
                    if spec.strip().__eq__(selected_spec.strip()):
                        print(f"✅ 已选中型号: {spec}")
                        continue
                    else:
                        spec_label=spec.strip()+"("+spec.strip()+")"
                        print(f"取消选中元素title={spec_label}")
                        edit_page.locator("div.options-module label[title='"+spec_label+"'] input[type='checkbox']").uncheck(timeout=1000)
                        continue
        except Exception as e:
            print(f"⚠️ 产品规格填充失败: {e}")
        # ... existing code ...
        if "title" in product_dict and product_dict["title"]:
            try:
                title_input = edit_page.locator("input[name='productTitleBuyer']")
                if title_input.is_visible():
                    # 针对店小秘平台优化标题长度
                    optimized_title = product_dict["title"][:200]
                    title_input.fill(optimized_title)
                    print(f"✅ 产品标题: {optimized_title[:50]}...")
            except Exception as e:
                print(f"⚠️ 标题填充失败: {e}")
        
        # Fill product description - 优先使用Key Features
        description_text = ""
        if "key features" in product_dict:
            description_text = product_dict["key features"]
        
        if description_text:
            try:
                desc_input = edit_page.locator("textarea[name='productDesc']")
                if desc_input.is_visible():
                    # 针对店小秘平台优化描述长度
                    optimized_desc = description_text[:1000]
                    desc_input.fill(optimized_desc)
                    print(f"✅ 产品描述: {len(optimized_desc)} 字符")
            except Exception as e:
                print(f"⚠️ 描述填充失败: {e}")
                
                
        
        # 表格信息开始------
         # Fill sku (if available)
        if "asin" in product_dict and product_dict["asin"]:
            try:
                sku_inputs = edit_page.locator("input[name='sku']")
                if sku_inputs.count() > 0:
                    # 清理价格数据
                        sku_inputs.first.fill(product_dict["asin"])
                        print(f"✅ 表格中sku: {product_dict['asin']}")
            except Exception as e:
                print(f"⚠️ sku填充失败: {e}")
        
        # Fill price (if available)
        if "price" in product_dict and product_dict["price"]:
            try:
                price_inputs = edit_page.locator("input[name='price']")
                if price_inputs.count() > 0:
                    # 清理价格数据
                    clean_price = float(product_dict["price"]) + float(product_dict['delivery price'])
                    if clean_price:
                        price_inputs.first.fill(str(clean_price))
                        print(f"✅ 产品价格: {clean_price}")
            except Exception as e:
                print(f"⚠️ 价格填充失败: {e}")
        # Fill weight (convert from pounds to grams)
        if "item weight" in product_dict and product_dict["item weight"]:
            try:
                weight_inputs = edit_page.locator("input[name='weight']")
                if weight_inputs.count() > 0:
                    # 转换重量从磅到克
                    weight_in_grams = convert_weight_to_grams(product_dict["item weight"])
                    if weight_in_grams:
                        weight_inputs.first.fill(weight_in_grams)
                        print(f"✅ 产品重量: {weight_in_grams}g (原值: {product_dict['item weight']})")
            except Exception as e:
                print(f"⚠️ 重量填充失败: {e}")
        # 批量编辑SKU图片大小
        try:
            edit_page.locator("table").filter(has_text="SKU图片").get_by_text("批量").first.click()
            edit_page.locator("li.ant-dropdown-menu-item", has_text="批量改图片尺寸").click()
            input_elements = edit_page.locator("input[name='valueW']")    
            input_elements.first.fill("1500")
            submit_btn = edit_page.get_by_role("button", name="生成JPG图片")
            submit_btn.click()
            print("✅ 编辑SKU图片大小完成")
        except Exception as e:
            print(f"⚠️ 批量编辑SKU图片图片失败: {e}")
        # 表格信息结束------
        edit_page.wait_for_timeout(2000)
        # 批量编辑变种图片大小
        try:
            editPic = edit_page.locator("div#skuImageInfo").get_by_text("编辑图片").first
            print("✅ 准备点击编辑图片")
            print(editPic.inner_html)
            if editPic.is_visible():
                editPic.click()
                edit_page.get_by_role("menuitem", name="批量改图片尺寸").first.click()
                # edit_page.locator("li.ant-dropdown-menu-item", has_text="批量改图片尺寸").click()
                input_elements = edit_page.locator("input[name='valueW']")    
                input_elements.first.fill("1500")
                submit_btn = edit_page.get_by_role("button", name="生成JPG图片")
                submit_btn.click()
                print("✅ 编辑变种图片大小完成")
        except Exception as e:
            print(f"⚠️ 编辑变种图片失败: {e}")
        edit_page.wait_for_timeout(2000)
        # 批量编辑详情图大小
        try:
            editPic = edit_page.locator("div#skuDescInfo").get_by_text("编辑图片").first
            if editPic.is_visible():
                editPic.click()
                edit_page.get_by_role("menuitem", name="批量改图片尺寸").first.click()
                # edit_page.locator("li.ant-dropdown-menu-item", has_text="批量改图片尺寸").click()
                input_elements = edit_page.locator("input[name='valueW']")    
                input_elements.first.fill("1500")
                submit_btn = edit_page.get_by_role("button", name="生成JPG图片")
                submit_btn.click()
                print("✅ 编辑详情图大小完成")
        except Exception as e:
            print(f"⚠️ 编辑详情图片失败: {e}")
        # 在手动模式下，显示更多可填充的字段信息
        if manual_mode:
            fillable_fields = ['Brand', 'Material', 'Color', 'Style']
            available_fields = [field for field in fillable_fields if field in product_dict]
            if available_fields:
                print("📋 可用属性信息:")
                for field in available_fields:
                    print(f"  - {field}: {product_dict[field]}")
        
        print("✅ 表单填充完成")
        
    except Exception as e:
        print(f"❌ 表单填充失败: {e}")
        
def save_product_changes_enhanced(edit_page: Page, manual_mode: bool = False,title:str='') -> bool:
    """
    增强版保存函数 - 针对店小秘平台优化
    
    Args:
        edit_page: 编辑页面对象
        manual_mode: 是否为手动模式
        
    Returns:
        bool: 保存是否成功
    """
    try:
        # if manual_mode:
            # # 手动模式：询问用户是否保存
            # while True:
            #     save_choice = input("💾 是否保存产品? [Y]是 / [N]否: ").strip().upper()
            #     if save_choice in ['Y', 'YES', '']:
            #         break
            #     elif save_choice in ['N', 'NO']:
            #         print("⏭️ 用户选择不保存")
            #         return False
            #     else:
            #         print("❌ 无效选择，请输入 Y 或 N")
        edit_page.wait_for_timeout(2000)
        # 查找保存按钮

        save_button = edit_page.get_by_role("button", name=re.compile(r"^保存$")).first
        if save_button.is_visible():
            save_button.click()
            print("点击保存按钮")
            print(save_button.inner_html())
            print("✅ 产品已保存")
            print(f"✅ 产品标题：{title}")
            # Wait for save confirmation
            edit_page.wait_for_timeout(1000)
            edit_page.locator("button.ant-modal-close").first.click(timeout=5000)
            print("✅ 点击关闭编辑页弹框，自动关闭页面")
            print("✅ 编辑页面已正常关闭") 
            return True
        else:
            print("❌ 未找到保存按钮")
            return False
            
    except Exception as e:
        print(f"❌ 保存失败: {e}")
        print("强制关闭页面")
        edit_page.close()
        return False


def process_product_edit_enhanced(context, page: Page, edit_button, manual_mode: bool = False) -> bool:
    """
    增强版单个产品处理函数
    
    Args:
        context: Playwright上下文
        page: 主页面对象
        edit_button: 编辑按钮元素
        manual_mode: 是否为手动审核模式
        
    Returns:
        bool: 处理是否成功
    """
    edit_page = None  # Initialize to avoid unbound variable error
    try:
        # Click the edit button
        print("🔍 点击编辑按钮...")
        with page.context.expect_page() as edit_page_info:
            edit_button.click()
        
        edit_page = edit_page_info.value
        edit_page.wait_for_timeout(3000)
        print("✅ 编辑页面已打开")
        
        # Extract web_url from the sourceUrl input field
        try:
            web_url = edit_page.locator("input[name='sourceUrl']").input_value()
            print(f"🔗 提取产品链接: {web_url[:60]}...")
        except Exception as e:
            print(f"⚠️ 提取链接失败: {e}")
            web_url = None
        
        if not web_url:
            print("❌ 未找到访问链接，跳过此产品")
            edit_page.close()
            return False
        
        # 解析亚马逊产品数据
        product_data = parse_amazon_product_enhanced(context, web_url)
        
        if not product_data:
            print("❌ 产品解析失败")
            edit_page.close()
            return False
       
        if manual_mode:
            # 填充表单
            fill_edit_form_enhanced(edit_page, product_data, manual_mode)
            
            # 保存产品
            save_success = save_product_changes_enhanced(edit_page, manual_mode, product_data.title)
            
            return save_success
            
    except Exception as e:
        print(f"❌ 处理产品时出错: {e}")
        try:
            if edit_page is not None:
                edit_page.close()
        except:
            pass
        return False


def run_manual_mode(context, page):
    """手动审核模式 - 逐个产品审核"""
    print("\n" + "🔍"*20)
    print("🎯 店小秘手动审核模式")
    print("🔍"*20)
    
    # Get all edit buttons
    edit_buttons, count = get_edit_buttons(page)
    
    if count == 0:
        print("❌ 未找到编辑按钮!")
        return
    
    print(f"📊 发现 {count} 个产品待处理")
    
    processed = 0
    skipped = 0
    errors = 0
    auto_mode = False
    
    # Process each product with manual review
    for i in range(count):
        print(f"\n{'='*60}")
        print(f"🔍 处理产品 {i+1}/{count}")
        print("="*60)
        
        try:
            # Get fresh reference to the button (DOM might change)
            buttons, _ = get_edit_buttons(page)
            if i < buttons.count():
                success = process_product_edit_enhanced(context, page, buttons.nth(i), manual_mode=True)
                if success:
                    processed += 1
                    print(f"✅ 产品 {i+1} 处理完成")
                else:
                    skipped += 1
                    print(f"⏭️ 产品 {i+1} 已跳过")
            else:
                print(f"⚠️ 产品 {i+1} 按钮索引超出范围，跳过")
                skipped += 1
                
        except Exception as e:
            print(f"❌ 处理产品 {i+1} 时出错: {e}")
            errors += 1
        
        # 询问是否继续
        if i < count - 1:  # 不是最后一个产品
            print(f"\n📊 当前进度: 已处理 {processed}, 已跳过 {skipped}, 错误 {errors}")
            if auto_mode==False:
                continue_choice = input("🤔 继续下一个产品? [Y]是 / [N]结束 /[A] 自动继续不再询问: ").strip().upper()
                if continue_choice in ['N', 'NO']:
                    print("🛑 用户选择结束处理")
                    break
                elif continue_choice in ['A', 'AUTO']:
                    print("AUTO 用户选择自动继续不再询问")
                    auto_mode=True
        
        # Wait between operations
        page.wait_for_timeout(2000)
    
    print(f"\n{'='*80}")
    print("📊 手动审核模式处理完成")
    print(f"✅ 成功处理: {processed} 个产品")
    print(f"⏭️ 跳过: {skipped} 个产品") 
    print(f"❌ 错误: {errors} 个产品")
    print("="*80)
    
def closeAdModal(page: Page):
    """
    处理连续弹出的弹窗 - 优化版本
    处理先弹出一个，关闭后又弹出另一个的情况
    """
    try:
        max_attempts = 5  # 最多尝试关闭5个连续弹窗
        popup_closed = 0
        
        print("🔍 开始检查并关闭连续弹窗...")
        
        for attempt in range(max_attempts):
            # 等待弹窗出现
            page.wait_for_timeout(1500)
            
            # 检查是否有弹窗出现
            popup_found = False
            
            # 常见的弹窗关闭按钮选择器
            close_selectors = [
                "button:has-text('关闭')",
                "button[aria-label='关闭']",
                ".ant-modal-close",
                ".ant-modal-close-x", 
                "button.ant-btn:has-text('关闭')",
                "[class*='close']:has-text('关闭')",
                "button[title='关闭']",
                ".ant-modal-mask + .ant-modal-wrap .ant-modal-close",
                ".ant-modal .ant-modal-close-icon",
                "button:has-text('取消')",
                "button:has-text('知道了')",
                "button:has-text('确定')"
            ]
            
            # 尝试每个选择器
            for selector in close_selectors:
                try:
                    close_button = page.locator(selector).first
                    
                    # 检查按钮是否可见且可点击
                    if close_button.count() > 0 and close_button.is_visible():
                        print(f"  🎯 发现弹窗 {attempt + 1}，尝试关闭...")
                        close_button.click()
                        popup_closed += 1
                        popup_found = True
                        
                        # 等待弹窗关闭动画完成
                        page.wait_for_timeout(1000)
                        print(f"  ✅ 弹窗 {attempt + 1} 已关闭")
                        break  # 成功关闭一个弹窗后，跳出选择器循环
                        
                except Exception as selector_error:
                    # 当前选择器失败，尝试下一个
                    continue
            
            # 如果本轮没有找到弹窗，说明已经全部关闭
            if not popup_found:
                if attempt == 0:
                    print("  ℹ️ 未发现弹窗")
                else:
                    print(f"  ✅ 所有弹窗已处理完毕")
                break
        
        # 最终检查：确保没有遗漏的弹窗
        page.wait_for_timeout(500)
        
        if popup_closed > 0:
            print(f"🎉 成功关闭 {popup_closed} 个连续弹窗")
        
        return popup_closed
        
    except Exception as e:
        print(f"⚠️ 处理连续弹窗时出错: {e}")
        return 0
        
    
     
def run(playwright: Playwright) -> None:
    """
    主运行函数 - 保持原有的登录和会话管理逻辑
    """
    # 检查脚本有效期
    check_script_expiration()
    
    # 登录信息
    user_name = "liyoutest001"
    password = "Aa741852963."
    # # 备用登录信息
    # user_name = "18256261013"
    # password = "Aa741852963"
    
    browser = playwright.chromium.launch(headless=False)
    
    # 尝试加载存储的状态
    storage_state = f"{user_name}_auth_state.json"
    if os.path.exists(storage_state):
        context = browser.new_context(storage_state=storage_state, no_viewport=True)  
    else:
        context = browser.new_context(no_viewport=True)
    
    page = context.new_page()
    
    try:
        page.goto("https://www.dianxiaomi.com/")
        # 检查是否已登录
        if page.locator("text=立即登录").count() > 0:
            raise Exception("Not logged in")
    except Exception as e:
        # 需要登录
        print(f"🔐 需要登录: {e}")
        page.get_by_role("textbox", name="请输入用户名").click()
        page.get_by_role("textbox", name="请输入用户名").fill(user_name)
        page.get_by_role("textbox", name="请输入密码").click()
        page.get_by_role("textbox", name="请输入密码").fill(password)
        input("等待登录后按回车键继续\n")
        # Save authentication state
        page.context.storage_state(path=storage_state)
        print("✅ 登录成功，状态已保存")
    
    page.goto("https://www.dianxiaomi.com/web/sheinProduct/draft")
    print("✅ 已导航到采集箱列表")
    
    # 再次检查弹窗（页面跳转后可能出现新弹窗）
    closeAdModal(page)

    closeAdModal(page)
    run_manual_mode(context, page)
    
    # 清理资源
    print("\n🏁 所有操作已完成，浏览器保持打开状态供您继续操作...")
    input("按Enter键退出程序并关闭浏览器...")
    context.close()
    browser.close()


def main():
    """程序入口点"""
    print("🌟 重构后的数字酋长自动化系统")
    print("📋 重构成果:")
    print("   ✅ 统一Amazon解析器")
    print("   ✅ 统一表单填充引擎")  
    print("   ✅ 单一映射系统")
    print("   ✅ 简化的数据流")
    print()
    
    with sync_playwright() as playwright:
        run(playwright)


if __name__ == "__main__":
    main()
