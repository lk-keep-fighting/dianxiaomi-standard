"""
Digital Chief Automation - Source Package
Browser automation tool for digital marketing and data extraction
"""

__version__ = "1.0.0"
__author__ = "Digital Chief Team"