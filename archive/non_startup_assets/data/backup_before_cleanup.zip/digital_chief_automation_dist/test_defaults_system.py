#!/usr/bin/env python3
"""
默认值配置系统综合测试
验证默认值管理器的各种功能和策略
"""
import sys
import os
import json

# 添加src目录到Python路径
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from field_defaults_manager import FieldDefaultsManager
from form_config_listener import FormConfigListener, FormFieldParser
from dynamic_form_filler import DynamicFormFiller

def test_defaults_manager_basic():
    """测试默认值管理器基础功能"""
    print("🧪 测试默认值管理器基础功能...")
    
    manager = FieldDefaultsManager()
    
    # 测试基本信息
    stats = manager.get_stats()
    print(f"📊 配置统计: {stats}")
    
    # 测试精确匹配
    field_config = {
        'title': 'Is Prop 65 Warning Required',
        'input_type': 'select'
    }
    
    default_value = manager.get_default_value(field_config)
    print(f"✅ 精确匹配测试: {field_config['title']} -> '{default_value}'")
    
    assert default_value == "No", f"期望 'No', 实际得到 '{default_value}'"
    
    return True

def test_pattern_matching():
    """测试模式匹配功能"""
    print("\n🧪 测试模式匹配功能...")
    
    manager = FieldDefaultsManager()
    
    test_cases = [
        {
            'title': 'Product Color Selection',
            'input_type': 'select',
            'expected_pattern': '*Color*',
            'expected_value': 'Multi-Color'
        },
        {
            'title': 'Assembled Product Weight',
            'input_type': 'number', 
            'expected_pattern': '*Weight*',
            'expected_value': '10'
        },
        {
            'title': 'Brand Name',
            'input_type': 'text',
            'expected_pattern': '*Brand*',
            'expected_value': 'Generic'
        }
    ]
    
    for i, test_case in enumerate(test_cases, 1):
        field_config = {
            'title': test_case['title'],
            'input_type': test_case['input_type']
        }
        
        default_value = manager.get_default_value(field_config)
        expected = test_case['expected_value']
        
        print(f"📋 测试 {i}: {test_case['title']}")
        print(f"   模式: {test_case['expected_pattern']}")
        print(f"   结果: '{default_value}' (期望: '{expected}')")
        
        status = "✅" if default_value == expected else "❌"
        print(f"   {status}")
        
        if default_value != expected:
            print(f"   ⚠️ 不匹配！实际: '{default_value}', 期望: '{expected}'")

def test_contextual_defaults():
    """测试基于上下文的默认值"""
    print("\n🧪 测试上下文默认值功能...")
    
    manager = FieldDefaultsManager()
    
    # 测试家具类上下文
    furniture_context = {'category': 'furniture'}
    field_config = {
        'title': 'Material',
        'input_type': 'select'
    }
    
    default_value = manager.get_default_value(field_config, furniture_context)
    print(f"🪑 家具上下文: Material -> '{default_value}' (期望: 'Wood')")
    
    # 测试电子类上下文
    electronics_context = {'category': 'electronics'}
    field_config = {
        'title': 'Power Source',
        'input_type': 'select'
    }
    
    default_value = manager.get_default_value(field_config, electronics_context)
    print(f"🔌 电子类上下文: Power Source -> '{default_value}' (期望: 'Electric')")
    
    return True

def test_category_based_defaults():
    """测试基于字段类别的默认值"""
    print("\n🧪 测试类别默认值功能...")
    
    manager = FieldDefaultsManager()
    
    test_cases = [
        {
            'title': 'Product Weight (lbs)',
            'input_type': 'number',
            'expected_category': 'weight',
            'expected_value': '5.0'
        },
        {
            'title': 'Product Width',
            'input_type': 'number',
            'expected_category': 'dimension', 
            'expected_value': '12.0'
        },
        {
            'title': 'Package Quantity',
            'input_type': 'number',
            'expected_category': 'quantity',
            'expected_value': '1'
        }
    ]
    
    for test_case in test_cases:
        field_config = {
            'title': test_case['title'],
            'input_type': test_case['input_type']
        }
        
        default_value = manager.get_default_value(field_config)
        expected = test_case['expected_value']
        
        print(f"📏 {test_case['title']}")
        print(f"   类别: {test_case['expected_category']}")
        print(f"   结果: '{default_value}' (期望: '{expected}')")
        
        status = "✅" if str(default_value) == expected else "⚠️"
        print(f"   {status}")

def test_type_based_defaults():
    """测试基于类型的默认值"""
    print("\n🧪 测试类型默认值功能...")
    
    manager = FieldDefaultsManager()
    
    test_cases = [
        {
            'title': 'Unknown Text Field',
            'input_type': 'text',
            'expected': ''
        },
        {
            'title': 'Unknown Number Field', 
            'input_type': 'number',
            'expected': '0'
        },
        {
            'title': 'Unknown Select Field',
            'input_type': 'select',
            'expected': 'Please select'
        },
        {
            'title': 'Unknown Textarea Field',
            'input_type': 'textarea',
            'expected': 'No additional description'
        }
    ]
    
    for test_case in test_cases:
        field_config = {
            'title': test_case['title'],
            'input_type': test_case['input_type']
        }
        
        default_value = manager.get_default_value(field_config)
        expected = test_case['expected']
        
        print(f"📝 {test_case['input_type']} 类型测试: '{default_value}' (期望: '{expected}')")
        
        if str(default_value) != expected:
            print(f"   ⚠️ 类型默认值不匹配")

def test_priority_order():
    """测试优先级顺序"""
    print("\n🧪 测试优先级顺序...")
    
    manager = FieldDefaultsManager()
    
    # 测试一个既有精确匹配又有模式匹配的字段
    field_config = {
        'title': 'Age Group',  # 精确匹配存在
        'input_type': 'select'
    }
    
    default_value = manager.get_default_value(field_config)
    print(f"🎯 优先级测试: Age Group -> '{default_value}'")
    print(f"   应该使用精确匹配 'Adult' 而不是模式匹配结果")
    
    assert default_value == "Adult", "优先级测试失败"
    print("✅ 优先级顺序正确")

def test_dynamic_configuration():
    """测试动态配置功能"""
    print("\n🧪 测试动态配置功能...")
    
    manager = FieldDefaultsManager()
    
    # 动态添加默认值
    success = manager.add_default_value("Test Dynamic Field", "Dynamic Value", "exact_match")
    print(f"➕ 动态添加结果: {success}")
    
    # 验证新添加的值
    field_config = {
        'title': 'Test Dynamic Field',
        'input_type': 'text'
    }
    
    default_value = manager.get_default_value(field_config)
    print(f"✅ 验证动态值: {default_value}")
    
    assert default_value == "Dynamic Value", "动态配置测试失败"
    
    # 测试缓存
    manager.clear_cache()
    print("🗑️ 缓存已清空")
    
    # 再次获取应该重新计算
    default_value = manager.get_default_value(field_config)
    print(f"🔄 重新计算值: {default_value}")

def test_integration_with_form_filler():
    """测试与表单填充器的集成"""
    print("\n🧪 测试与表单填充器的集成...")
    
    # 模拟表单配置
    listener = FormConfigListener()
    config = listener.load_config()
    
    if not config:
        print("⚠️ 需要表单配置才能进行集成测试")
        return False
    
    parser = FormFieldParser(config)
    
    # 创建测试产品数据
    test_product = {
        'title': 'Test Product',
        'Brand': 'Test Brand'
    }
    
    # 模拟表单填充器
    class MockFrame:
        def locator(self, selector):
            return MockLocator()
        def get_by_role(self, role, **kwargs):
            return MockLocator()
    
    class MockLocator:
        def fill(self, value, **kwargs):
            print(f"    模拟填充: '{value}'")
        def click(self, **kwargs):
            pass
        def press(self, key):
            pass
        def wait_for(self, **kwargs):
            pass
        def count(self):
            return 0
    
    mock_frame = MockFrame()
    
    # 创建表单填充器（集成默认值管理器）
    form_filler = DynamicFormFiller(mock_frame, parser, test_product, None, False)
    
    # 测试获取不存在字段的默认值
    all_fields = parser.get_all_fields()
    test_fields = all_fields[:5]  # 测试前5个字段
    
    print(f"📋 测试前 {len(test_fields)} 个字段的默认值:")
    
    for field in test_fields:
        field_title = field['title']
        default_value = form_filler._get_default_value(field)
        
        if default_value is not None:
            print(f"  ✅ {field_title}: '{default_value}'")
        else:
            print(f"  ⚪ {field_title}: 无默认值")
    
    return True

def test_configuration_validation():
    """测试配置验证"""
    print("\n🧪 测试配置验证...")
    
    manager = FieldDefaultsManager()
    
    # 验证配置完整性
    if manager.config:
        required_sections = ['defaults', 'configuration']
        for section in required_sections:
            if section not in manager.config:
                print(f"❌ 缺少配置段: {section}")
                return False
            else:
                print(f"✅ 配置段存在: {section}")
        
        # 验证默认值策略
        defaults = manager.config.get('defaults', {})
        required_strategies = ['exact_match', 'pattern_match', 'type_based']
        
        for strategy in required_strategies:
            if strategy in defaults:
                print(f"✅ 策略存在: {strategy}")
            else:
                print(f"⚠️ 策略缺失: {strategy}")
    
    print("✅ 配置验证完成")
    
    return True

def main():
    """主测试函数"""
    print("🚀 默认值配置系统综合测试")
    print("=" * 60)
    
    test_results = {}
    
    # 运行各项测试
    test_functions = [
        ("基础功能", test_defaults_manager_basic),
        ("模式匹配", test_pattern_matching), 
        ("上下文默认值", test_contextual_defaults),
        ("类别默认值", test_category_based_defaults),
        ("类型默认值", test_type_based_defaults),
        ("优先级顺序", test_priority_order),
        ("动态配置", test_dynamic_configuration),
        ("表单集成", test_integration_with_form_filler),
        ("配置验证", test_configuration_validation)
    ]
    
    for test_name, test_func in test_functions:
        try:
            print(f"\n{'='*60}")
            result = test_func()
            test_results[test_name] = "✅ 通过" if result else "⚠️ 部分问题"
        except Exception as e:
            test_results[test_name] = f"❌ 失败: {e}"
            print(f"❌ 测试失败: {e}")
    
    # 显示测试摘要
    print(f"\n{'='*60}")
    print("🎉 测试摘要")
    print("=" * 60)
    
    for test_name, result in test_results.items():
        print(f"{result} {test_name}")
    
    passed_count = sum(1 for result in test_results.values() if "✅" in result)
    total_count = len(test_results)
    
    print(f"\n📊 总体结果: {passed_count}/{total_count} 项测试通过")
    
    print(f"\n💡 默认值系统特性:")
    print("1. 🎯 精确字段名匹配")
    print("2. 🔍 通配符模式匹配")
    print("3. 🎨 基于上下文的智能默认值")
    print("4. 📏 基于字段类别的自动推断")
    print("5. 📝 基于字段类型的回退策略")
    print("6. ⚡ 可配置的优先级顺序")
    print("7. 🔄 动态配置和缓存管理")
    print("8. 🔗 与现有表单填充器的无缝集成")
    
    print(f"\n🎯 预期效果:")
    print("- 当字段无匹配值时，自动应用配置的默认值")
    print("- 减少手动填充工作量")
    print("- 提高表单完整性")
    print("- 支持不同产品类型的智能默认值")

if __name__ == "__main__":
    main()
