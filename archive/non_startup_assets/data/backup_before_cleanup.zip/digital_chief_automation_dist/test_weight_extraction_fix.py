#!/usr/bin/env python3
"""
重量提取修复验证测试
测试新的鲁棒重量提取逻辑
"""
import re
from typing import Dict, Any

def test_weight_extraction_strategies():
    """测试重量提取策略"""
    print("🧪 测试重量提取策略...")
    
    # 模拟不同格式的产品详情数据
    test_cases = [
        {
            'name': '标准格式 - Item Weight在详情中',
            'detail_pairs': {
                'Item Weight': '8.5 pounds',
                'Product Dimensions': '24 x 12 x 36 inches'
            },
            'expected': '8.5'
        },
        {
            'name': '小数重量',
            'detail_pairs': {
                'Item Weight': '2.35 lbs',
                'Color': 'Black'
            },
            'expected': '2.35'
        },
        {
            'name': '整数重量',
            'detail_pairs': {
                'Item Weight': '10 pounds',
                'Brand': 'TestBrand'
            },
            'expected': '10'
        },
        {
            'name': '重量带额外文字',
            'detail_pairs': {
                'Item Weight': 'Approximately 5.7 pounds when assembled',
                'Material': 'Wood'
            },
            'expected': '5.7'
        },
        {
            'name': '没有重量信息',
            'detail_pairs': {
                'Color': 'Red',
                'Brand': 'TestBrand'
            },
            'expected': '10'  # 默认值
        },
        {
            'name': '重量信息格式异常',
            'detail_pairs': {
                'Item Weight': 'N/A',
                'Style': 'Modern'
            },
            'expected': '10'  # 默认值
        }
    ]
    
    print(f"\n🔍 开始测试 {len(test_cases)} 种重量提取场景:")
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n📋 测试 {i}: {test_case['name']}")
        print(f"   输入详情: {test_case['detail_pairs']}")
        
        # 模拟策略1：从detail_pairs提取重量
        weight_value = '10'  # 默认值
        detail_pairs = test_case['detail_pairs']
        
        if 'Item Weight' in detail_pairs:
            try:
                weight_str = detail_pairs['Item Weight']
                weight_match = re.search(r'([0-9.]+)', weight_str)
                if weight_match:
                    weight_value = weight_match.group(1)
                    print(f"   ✅ 从产品详情获取重量: {weight_value} (原值: {weight_str})")
                else:
                    print(f"   ⚠️ 无法从 '{weight_str}' 中提取数字")
            except Exception as e:
                print(f"   ❌ 解析产品详情重量失败: {e}")
        else:
            print(f"   ℹ️ 详情中未找到 'Item Weight' 字段")
        
        expected = test_case['expected']
        status = "✅" if weight_value == expected else "❌"
        print(f"   {status} 提取结果: '{weight_value}' (期望: '{expected}')")
        
        if weight_value != expected:
            print(f"      ⚠️ 不匹配！可能需要进一步处理")

def test_element_text_parsing():
    """测试元素文本解析逻辑"""
    print(f"\n🧪 测试元素文本解析逻辑...")
    
    # 模拟从页面元素获取的各种文本格式
    element_text_cases = [
        {
            'text': 'Item Weight\t8.5 pounds',
            'expected': '8.5'
        },
        {
            'text': '8.75 lbs',
            'expected': '8.75'
        },
        {
            'text': 'Weight: 12.3 pounds (shipping weight may vary)',
            'expected': '12.3'
        },
        {
            'text': '5.25',  # 只有数字
            'expected': '5.25'
        },
        {
            'text': 'Lightweight design',  # 没有重量数字
            'expected': None
        },
        {
            'text': 'Item Weight: 3.2 kg (converted: 7.05 lbs)',
            'expected': '7.05'  # 应该提取lbs的值
        }
    ]
    
    print(f"🔍 测试 {len(element_text_cases)} 种文本解析场景:")
    
    for i, test_case in enumerate(element_text_cases, 1):
        text = test_case['text']
        expected = test_case['expected']
        
        print(f"\n📋 测试 {i}: '{text}'")
        
        # 策略1: 带单位的重量匹配
        weight_match = re.search(r'([0-9.]+)\s*(?:pounds?|lbs?)', text, re.IGNORECASE)
        if weight_match:
            result = weight_match.group(1)
            print(f"   🎯 策略1 (带单位): {result}")
        else:
            # 策略2: 纯数字匹配
            number_match = re.search(r'([0-9.]+)', text)
            if number_match:
                result = number_match.group(1)
                print(f"   🔢 策略2 (纯数字): {result}")
            else:
                result = None
                print(f"   ❌ 无法提取数字")
        
        status = "✅" if result == expected else "❌"
        print(f"   {status} 提取结果: '{result}' (期望: '{expected}')")

def test_selector_strategies():
    """测试选择器策略"""
    print(f"\n🧪 测试选择器策略...")
    
    selectors = [
        "td:has-text('Item Weight') span.a-size-base.handle-overflow",
        "td:has-text('Item Weight') span", 
        "td:has-text('Item Weight')",
        "[data-feature-name*='weight'], [id*='weight'], .weight-info",
        "#productDetails_detailBullets_sections1 span:has-text('pounds'), #productDetails_detailBullets_sections1 span:has-text('lbs')"
    ]
    
    print(f"📏 定义了 {len(selectors)} 个重量选择器策略:")
    
    for i, selector in enumerate(selectors, 1):
        print(f"   策略 {i}: {selector}")
        
        # 分析选择器的特点
        if 'Item Weight' in selector:
            print(f"      🎯 目标: 直接定位Item Weight单元格")
        elif 'weight' in selector.lower():
            print(f"      🔍 目标: 通用重量相关元素")
        elif 'pounds' in selector or 'lbs' in selector:
            print(f"      ⚖️ 目标: 包含重量单位的元素")
        
        # 分析选择器的精确性
        if 'span.a-size-base.handle-overflow' in selector:
            print(f"      📐 精确度: 高 (特定CSS类)")
        elif 'span' in selector:
            print(f"      📐 精确度: 中 (通用标签)")
        else:
            print(f"      📐 精确度: 低 (宽泛匹配)")

def simulate_weight_extraction_flow():
    """模拟完整的重量提取流程"""
    print(f"\n🧪 模拟完整重量提取流程...")
    
    # 模拟场景：策略1失败，需要使用策略2
    print("📋 场景: detail_pairs中没有Item Weight")
    
    detail_pairs = {
        'Product Dimensions': '24 x 12 x 36 inches',
        'Color': 'Black',
        'Brand': 'TestBrand'
    }
    
    weight_value = '10'  # 默认值
    
    # 策略1: 从detail_pairs获取
    if 'Item Weight' in detail_pairs:
        print("✅ 从detail_pairs获取重量")
    else:
        print("⚠️ detail_pairs中未找到Item Weight，需要使用策略2")
        
        # 策略2: 模拟页面元素提取
        print("🔍 模拟页面元素提取...")
        
        # 模拟不同选择器的返回结果
        mock_element_results = [
            None,  # 策略1失败
            None,  # 策略2失败  
            "Item Weight\t7.2 pounds",  # 策略3成功
        ]
        
        selectors = [
            "td:has-text('Item Weight') span.a-size-base.handle-overflow",
            "td:has-text('Item Weight') span",
            "td:has-text('Item Weight')"
        ]
        
        for i, (selector, mock_result) in enumerate(zip(selectors, mock_element_results), 1):
            print(f"   尝试策略 {i}: {selector[:50]}...")
            
            if mock_result is None:
                print(f"   ❌ 策略 {i} 失败: 未找到元素")
                continue
            else:
                print(f"   ✅ 策略 {i} 找到元素: {mock_result}")
                
                # 提取重量
                weight_match = re.search(r'([0-9.]+)', mock_result)
                if weight_match:
                    weight_value = weight_match.group(1)
                    print(f"   🎯 成功提取重量: {weight_value}")
                    break
    
    print(f"🎩 最终重量值: {weight_value}")

def main():
    """主测试函数"""
    print("🚀 重量提取修复验证测试")
    print("=" * 60)
    print("目标：验证新的鲁棒重量提取逻辑能够处理各种场景")
    
    test_weight_extraction_strategies()
    test_element_text_parsing()  
    test_selector_strategies()
    simulate_weight_extraction_flow()
    
    print("\n" + "=" * 60)
    print("🎉 测试完成！")
    
    print("\n💡 修复要点:")
    print("1. 🔧 优先从已提取的detail_pairs中获取重量")
    print("2. 🎯 使用多层级选择器策略作为后备")
    print("3. ⏱️ 减少每个选择器的超时时间（3秒 → 避免长时间等待）")
    print("4. 🔍 支持多种重量文本格式（pounds, lbs, 纯数字）")
    print("5. 🛡️ 增强错误处理和日志输出")
    print("6. 📊 提供详细的提取过程日志")
    
    print("\n🎯 预期修复效果:")
    print("- 减少因特定选择器失效导致的超时错误")
    print("- 提高重量信息的提取成功率")
    print("- 更快的错误恢复和降级处理")
    print("- 支持更多Amazon页面布局变化")

if __name__ == "__main__":
    main()
